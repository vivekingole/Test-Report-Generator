﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UiPath.Shared.Activities.Template
{
    class Data
    {
        public static String name = "vivek";
    }
}
