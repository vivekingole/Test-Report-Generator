using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using Self.UiPathReporter.Activities.Activities.Template.Recorder;
using Self.UiPathReporter.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Self.UiPathReporter.Activities
{
    [LocalizedDisplayName(nameof(Resources.StopRecording_DisplayName))]
    [LocalizedDescription(nameof(Resources.StopRecording_Description))]
    public class StopRecording : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        #endregion


        #region Constructors

        public StopRecording()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs

            ///////////////////////////
            if (Recorder.isRecording)
            {
                Recorder.recorder.Dispose();
                Recorder.isRecording = false;
            }

           
            ///////////////////////////

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

