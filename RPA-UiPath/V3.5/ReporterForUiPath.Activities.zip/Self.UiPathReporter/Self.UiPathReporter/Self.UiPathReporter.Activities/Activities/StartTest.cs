using System;
using System.Activities;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Self.UiPathReporter.Activities.Activities.Template;
using Self.UiPathReporter.Activities.Properties;
using SharpAvi;
using SharpAvi.Codecs;
using SharpAvi.Output;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Self.UiPathReporter.Activities
{
    [LocalizedDisplayName(nameof(Resources.StartTest_DisplayName))]
    [LocalizedDescription(nameof(Resources.StartTest_Description))]
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class StartTest : ContinuableAsyncCodeActivity
    {
        #region Properties
        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TestName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TestName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> TestName { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TagName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TagName_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> TagName { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TestDescription_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TestDescription_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> TestDescription { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_Priority_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_Priority_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public Enums.Priority Priority { get; set; } = Enums.Priority.Low;

        #endregion


        #region Constructors

        public StartTest()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (TestName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(TestName)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var testname = TestName.Get(context);
            var tagname = TagName.Get(context);
            var testdescription = TestDescription.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                ReportTemplate rp = new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suiteCreated)
            {
                ReportTemplate.suites.Add(ReportTemplate.currentSuite);
                ReportTemplate.suiteReportData.Add(ReportTemplate.currentSuite, new List<Int32>() { 0, 0 });
                ReportTemplate.suiteCreated = true;
            }
            if (!ReportTemplate.tags.Contains(tagname) && tagname != null)
            {
                ReportTemplate.tags.Add(tagname);
                ReportTemplate.tagReportData.Add(tagname, new List<Int32>() { 0, 0 });
            }
            if (tagname == null)
            {
                tagname = "";
            }
            TestItem test = new TestItem(testname, testdescription, tagname, Priority.ToString());
            ReportTemplate.endDate = Utility.getCurrentDate("/");
            ReportTemplate.endTime = Utility.getCurrentTime(":");
            ReportTemplate.testItems.Add(ReportTemplate.currentTestId, test);
            ReportTemplate.testCreated = true;
            ReportTemplate.counts["parentCount"] = ReportTemplate.testItems.Count;
            ReportTemplate.counts["passParent"]++;
            ReportTemplate.updateReport();

          
            ///////////////////////////

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }

}

