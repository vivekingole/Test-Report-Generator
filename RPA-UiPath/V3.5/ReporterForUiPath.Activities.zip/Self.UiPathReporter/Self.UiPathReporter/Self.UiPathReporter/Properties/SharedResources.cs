﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Self.UiPathReporter.Properties.Resources
    {
    }
}