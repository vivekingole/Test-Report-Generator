namespace Self.UiPathReporter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for StartRecordingDesigner.xaml
    /// </summary>
    public partial class StartRecordingDesigner
    {
        public StartRecordingDesigner()
        {
            InitializeComponent();
        }
    }
}
