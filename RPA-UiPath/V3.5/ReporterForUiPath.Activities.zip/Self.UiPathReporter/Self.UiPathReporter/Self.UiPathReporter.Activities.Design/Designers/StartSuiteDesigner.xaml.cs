namespace Self.UiPathReporter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for StartSuiteDesigner.xaml
    /// </summary>
    public partial class StartSuiteDesigner
    {
        public StartSuiteDesigner()
        {
            InitializeComponent();
        }
    }
}
