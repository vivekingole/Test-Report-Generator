namespace Self.UiPathReporter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for StepStatusDesigner.xaml
    /// </summary>
    public partial class StepStatusDesigner
    {
        public StepStatusDesigner()
        {
            InitializeComponent();
        }
    }
}
