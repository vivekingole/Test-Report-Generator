namespace ReporterForUiPath.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendEmailStatusDesigner.xaml
    /// </summary>
    public partial class SendEmailStatusDesigner
    {
        public SendEmailStatusDesigner()
        {
            InitializeComponent();
        }
    }
}
