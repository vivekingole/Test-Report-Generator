namespace ReporterForUiPath.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for StopRecordingDesigner.xaml
    /// </summary>
    public partial class StopRecordingDesigner
    {
        public StopRecordingDesigner()
        {
            InitializeComponent();
        }
    }
}
