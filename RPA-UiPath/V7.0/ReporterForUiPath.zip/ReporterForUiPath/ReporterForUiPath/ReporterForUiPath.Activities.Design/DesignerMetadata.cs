using ReporterForUiPath.Activities.Design.Designers;
using ReporterForUiPath.Activities.Design.Properties;
using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;

namespace ReporterForUiPath.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(CreateReport), categoryAttribute);
            builder.AddCustomAttributes(typeof(CreateReport), new DesignerAttribute(typeof(CreateReportDesigner)));
            builder.AddCustomAttributes(typeof(CreateReport), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(StartSuite), categoryAttribute);
            builder.AddCustomAttributes(typeof(StartSuite), new DesignerAttribute(typeof(StartSuiteDesigner)));
            builder.AddCustomAttributes(typeof(StartSuite), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(StartTest), categoryAttribute);
            builder.AddCustomAttributes(typeof(StartTest), new DesignerAttribute(typeof(StartTestDesigner)));
            builder.AddCustomAttributes(typeof(StartTest), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(StepStatus), categoryAttribute);
            builder.AddCustomAttributes(typeof(StepStatus), new DesignerAttribute(typeof(StepStatusDesigner)));
            builder.AddCustomAttributes(typeof(StepStatus), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(StartRecording), categoryAttribute);
            builder.AddCustomAttributes(typeof(StartRecording), new DesignerAttribute(typeof(StartRecordingDesigner)));
            builder.AddCustomAttributes(typeof(StartRecording), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(StopRecording), categoryAttribute);
            builder.AddCustomAttributes(typeof(StopRecording), new DesignerAttribute(typeof(StopRecordingDesigner)));
            builder.AddCustomAttributes(typeof(StopRecording), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(SendEmailStatus), categoryAttribute);
            builder.AddCustomAttributes(typeof(SendEmailStatus), new DesignerAttribute(typeof(SendEmailStatusDesigner)));
            builder.AddCustomAttributes(typeof(SendEmailStatus), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
