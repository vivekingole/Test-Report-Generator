﻿namespace UiPath.Shared.Localization
{
    class SharedResources : ReporterForUiPath.Activities.Design.Properties.Resources
    {
    }
}