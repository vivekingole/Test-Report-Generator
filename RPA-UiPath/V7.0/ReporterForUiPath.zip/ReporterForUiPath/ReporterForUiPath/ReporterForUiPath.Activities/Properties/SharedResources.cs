﻿namespace UiPath.Shared.Localization
{
    class SharedResources : ReporterForUiPath.Activities.Properties.Resources
    {
    }
}