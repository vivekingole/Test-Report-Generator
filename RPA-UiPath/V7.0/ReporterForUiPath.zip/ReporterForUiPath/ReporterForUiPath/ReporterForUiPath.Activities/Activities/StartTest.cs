using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.StartTest_DisplayName))]
    [LocalizedDescription(nameof(Resources.StartTest_Description))]
    public class StartTest : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TestName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TestName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> TestName { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TestDescription_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TestDescription_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> TestDescription { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_TagName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_TagName_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> TagName { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartTest_Priority_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartTest_Priority_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public ReporterForUiPath.Enums.Priority Priority { get; set; } = ReporterForUiPath.Enums.Priority.Low;

        [LocalizedDisplayName("Tests")]
        [LocalizedDescription("List of all Tests in current Report")]
        [LocalizedCategory("Output")]
        public OutArgument<List<String>> testList { get; set; }

        #endregion


        #region Constructors

        public StartTest()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (TestName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(TestName)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var testName = TestName.Get(context);
            var testDescription = TestDescription.Get(context);
            var tagName = TagName.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suiteCreated)
            {
                ReportTemplate.suites.Add(ReportTemplate.currentSuite);
                ReportTemplate.suiteReportData.Add(ReportTemplate.currentSuite, new List<Int32>() { 0, 0 });
                ReportTemplate.suiteCreated = true;
            }
            if (!ReportTemplate.tags.Contains(tagName) && tagName != null)
            {
                ReportTemplate.tags.Add(tagName);
                ReportTemplate.tagReportData.Add(tagName, new List<Int32>() { 0, 0 });
            }
            if (tagName == null)
            {
                tagName = "";
            }
            TestItem test = new TestItem(testName, testDescription, tagName, Priority.ToString());
            ReportTemplate.endDate = Utility.getCurrentDate("/");
            ReportTemplate.endTime = Utility.getCurrentTime(":");
            ReportTemplate.testItems.Add(ReportTemplate.currentTestId, test);
            ReportTemplate.testCreated = true;
            ReportTemplate.counts["parentCount"] = ReportTemplate.testItems.Count;
            ReportTemplate.counts["passParent"]++;
            ReportTemplate.updateReport();
            ///////////////////////////

            // Outputs
            return (ctx) =>
            {
                try
                {
                    List<String> tests = new List<string>();
                    foreach (TestItem item in ReportTemplate.testItems.Values)
                        tests.Add(item.testName);
                    testList.Set(ctx, tests);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    testList.Set(ctx, null);
                }
            };
        }

        #endregion
    }
}

