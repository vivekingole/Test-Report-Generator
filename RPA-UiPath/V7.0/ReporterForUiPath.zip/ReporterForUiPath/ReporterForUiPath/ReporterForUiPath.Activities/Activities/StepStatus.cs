using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.StepStatus_DisplayName))]
    [LocalizedDescription(nameof(Resources.StepStatus_Description))]
    public class StepStatus : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_Status_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_Status_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public ReporterForUiPath.Enums.StepStatus Status { get; set; } = ReporterForUiPath.Enums.StepStatus.Compare;

        [LocalizedDisplayName(nameof(Resources.StepStatus_Name_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_Name_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Name { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_Description_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_Description_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Description { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_ExpectedResult_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_ExpectedResult_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> ExpectedResult { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_ActualResult_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_ActualResult_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> ActualResult { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_CodeBlock_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_CodeBlock_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> CodeBlock { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_TakeScreenshot_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_TakeScreenshot_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public bool TakeScreenshot { get; set; } = true;

        [LocalizedDisplayName("Status")]
        [LocalizedDescription("Status of the Step")]
        [LocalizedCategory("Output")]
        public OutArgument<String> statusInfo { get; set; }

        #endregion


        #region Constructors

        public StepStatus()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Name == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Name)));
            if (Description == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Description)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var name = Name.Get(context);
            var description = Description.Get(context);
            var expectedResult = ExpectedResult.Get(context);
            var actualResult = ActualResult.Get(context);
            var codeBlock = CodeBlock.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suiteCreated)
            {
                ReportTemplate.suites.Add(ReportTemplate.currentSuite);
                ReportTemplate.suiteReportData.Add(ReportTemplate.currentSuite, new List<Int32>() { 0, 0 });
                ReportTemplate.suiteCreated = true;
            }
            if (!ReportTemplate.testCreated)
            {
                TestItem test = new TestItem("DefaultTest", "Default Test Created By UiPath Reporter", "", "Low");
                ReportTemplate.testItems.Add(ReportTemplate.currentTestId, test);
                ReportTemplate.testCreated = true;
                ReportTemplate.counts["parentCount"] = ReportTemplate.testItems.Count;
                ReportTemplate.counts["passParent"]++;
            }

            String statusStr = Status.ToString();
            if (statusStr.Equals("Compare"))
            {
                String Actual = (actualResult == null) ? "" : actualResult;
                String Expected = (expectedResult == null) ? "" : expectedResult;
                statusStr = (Actual.Equals(Expected) ? "Pass" : "Fail");
            }

            StepItem step = new StepItem(name, statusStr, description, TakeScreenshot);
            step.stepException = (codeBlock == null) ? "" : codeBlock;
            step.expectedResult = (expectedResult == null) ? "" : expectedResult;
            step.actualResult = (actualResult == null) ? "" : actualResult;
            ReportTemplate.endDate = Utility.getCurrentDate("/");
            ReportTemplate.endTime = Utility.getCurrentTime(":");
            ReportTemplate.testItems[ReportTemplate.currentTestId].endDate = ReportTemplate.endDate;
            ReportTemplate.testItems[ReportTemplate.currentTestId].endTime = ReportTemplate.endTime;
            ReportTemplate.testItems[ReportTemplate.currentTestId].stepItems.Add(step);
            ReportTemplate.updateReport();
            ///////////////////////////

            // Outputs
            return (ctx) =>
            {
                statusInfo.Set(ctx, statusStr);
            };
        }

        #endregion
    }
}

