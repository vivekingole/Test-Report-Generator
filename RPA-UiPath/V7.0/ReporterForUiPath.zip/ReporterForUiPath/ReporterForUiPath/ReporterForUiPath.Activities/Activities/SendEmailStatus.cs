using System;
using System.Activities;
using System.Net.Mail;
using System.Threading;
using System.Threading.Tasks;
using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.SendEmailStatus_DisplayName))]
    [LocalizedDescription(nameof(Resources.SendEmailStatus_Description))]
    public class SendEmailStatus : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_To_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_To_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> To { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_From_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_From_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> From { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_CC_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_CC_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> CC { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_BCC_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_BCC_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> BCC { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_Subject_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_Subject_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> Subject { get; set; }

        /*
        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_Body_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_Body_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> Body { get; set; }
        */

        [LocalizedDisplayName("Server")]
        [LocalizedDescription("Text must be quoted")]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> Server { get; set; }

        [LocalizedDisplayName("Port")]
        [LocalizedDescription("Text must be quoted")]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> Port { get; set; }

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_AttachCurrentReport_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_AttachCurrentReport_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public bool AttachCurrentReport { get; set; } = true;

        [LocalizedDisplayName(nameof(Resources.SendEmailStatus_IsEmailSent_DisplayName))]
        [LocalizedDescription(nameof(Resources.SendEmailStatus_IsEmailSent_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<bool> IsEmailSent { get; set; }

        #endregion


        #region Constructors

        public SendEmailStatus()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (To == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(To)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var to = To.Get(context);
            var from = From.Get(context);
            var cc = CC.Get(context);
            var bcc = BCC.Get(context);
            var subject = Subject.Get(context);
            //var body = Body.Get(context);
            var server = Server.Get(context);
            var port = Port.Get(context);
            Boolean ismailsent = false;
            ///////////////////////////
                      
                String fromstr = "";
                String ccstr = "";
                String bccstr = "";
                String subjectstr = "";
                String bodystr = "";
                String serverstr = "";
                String portstr = "";

                if (from == null)
                {
                    fromstr = "test.reporter0@gmail.com";
                }
                else
                {
                    fromstr = from.ToString();
                }

                if (server == null)
                {
                    serverstr = "smtp.gmail.com";
                }
                else
                {
                    serverstr = server.ToString();
                }

                if (port == null)
                {
                    portstr = "587";
                }
                else
                {
                    portstr = port.ToString();
                }

                if (cc == null)
                {
                    ccstr = "";
                }
                else
                {
                    ccstr = cc.ToString();
                }

                if (bcc == null)
                {
                    bccstr = "";
                }
                else
                {
                    bccstr = bcc.ToString();
                }

                if (subject == null)
                {
                    String reportname = "";
                    if (ReportTemplate.reportCreated)
                    {
                        reportname = "for the report : "+ReportTemplate.reportName+" ";
                    }
                    subjectstr = "Test Status "+reportname+Utility.getCurrentDate("_");
                }
                else
                {
                    subjectstr = subject.ToString();
                }

                if (ReportTemplate.reportCreated)
                {
                String tagTemplate = "";
                if (ReportTemplate.tagReportData.Count > 0)
                {
                    tagTemplate = $@"
Tagwise Report :
</br></br>
<table border=""1"" style=""border-spacing:0 0"">
   <thead>
    <tr style=""background-color:rgb(115,146,202); color: white"">
    <th>Tag</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
    {ReportTemplate.getReport(ReportTemplate.tagReportData)}
   </tbody>
</table>
</br></br>
";
                }

                        bodystr = $@"
Hi,
</br></br></br>
Test Execution Status :
</br></br>
<table border=""1"" style=""border-spacing:0 0"">
   <thead>
    <tr style=""background-color:rgb(115,146,202); color: white"">
    <th>Total Test</th>
    <th>Passed</th>
    <th>Failed</th>
    </tr>
   </thead>
   <tbody>
    <tr>
    <td> {ReportTemplate.counts["parentCount"]} </td>
    <td> {ReportTemplate.counts["passParent"]} </td>
    <td> {ReportTemplate.counts["failParent"]} </td>
    </tr>    
   </tbody>
</table>
</br></br>

Suitewise Report :
</br></br>
<table border=""1"" style=""border-spacing:0 0"">
   <thead>
    <tr style=""background-color:rgb(115,146,202); color: white"">
    <th>Suite</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
    {ReportTemplate.getReport(ReportTemplate.suiteReportData)}
   </tbody>
</table>
</br></br>

Priority Report :
</br></br>
<table border=""1"" style=""border-spacing:0 0"">
   <thead>
    <tr style=""background-color:rgb(115,146,202); color: white"">
    <th>Priority</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
    {ReportTemplate.getReport(ReportTemplate.priorityReportData)}
   </tbody>
</table>
</br></br>
{tagTemplate}
Thanks,</br>
Report Management Team
";
                    }
                    else
                    {
                        bodystr = $@"
Hi,
</br></br></br>
Report Creation has not been initiated !!
</br></br>
Thanks,</br>
Report Management Team
";
                    }
                
                if(to != null)
                {
                    MailMessage mail = new MailMessage();
                    SmtpClient SmtpServer = new SmtpClient(serverstr);
                    mail.From = new MailAddress(fromstr);
                    mail.To.Add(to.ToString());
                    mail.Subject = subjectstr;
                    mail.Body = bodystr;
                    if(ccstr.Length != 0)
                        mail.CC.Add(ccstr);
                    if (bccstr.Length != 0)
                        mail.Bcc.Add(bccstr);
                    mail.IsBodyHtml = true;
                    if(AttachCurrentReport == true && ReportTemplate.reportCreated)
                    {
                        mail.Attachments.Add(new Attachment(ReportTemplate.reportPath));
                    }
                    SmtpServer.Port = Convert.ToInt32(portstr.Trim());
                    SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
                    SmtpServer.UseDefaultCredentials = false;
                    SmtpServer.Credentials = new System.Net.NetworkCredential(fromstr, Resources.SendEmailStatus_Body_DisplayName);
                    SmtpServer.EnableSsl = true;
                    SmtpServer.Send(mail);
                    mail.Dispose();
                    ismailsent = true;
                }
                
           

            ///////////////////////////

            // Outputs
            return (ctx) => {
                IsEmailSent.Set(ctx, ismailsent);
            };
        }

        #endregion
    }
}

