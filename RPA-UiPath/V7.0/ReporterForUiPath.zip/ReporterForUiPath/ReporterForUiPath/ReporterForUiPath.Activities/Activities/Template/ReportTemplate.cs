﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Self.UiPathReporter.Activities.Activities.Template
{
    class ReportTemplate
    {
        // Status Variables
        public static bool reportCreated = false;
        public static bool suiteCreated = false;
        public static bool testCreated = false;

        // General Variables
        public static String reportName = "DefaultUiPathReport";
        public static String reportPath;
        public static String reportLocation = ".\\Reports\\";
        public static String screenshotLocation;
        public static String recordingsLocation;
        public static String startDate;
        public static String endDate;
        public static String startTime;
        public static String endTime;
        public static Int32 testCounter = 1;
        public static String currentTestId;
        public static String currentSuite = "DefaultSuite";
        public static String openingBrace = "{";
        public static String closingBrace = "}";

        // Collections
        public static List<String> suites = new List<String>();
        public static List<String> tags = new List<String>();
        public static Dictionary<String, TestItem> testItems = new Dictionary<String, TestItem>();
        public static Dictionary<String, Int32> counts = new Dictionary<String, Int32>();
        public static Dictionary<String, List<Int32>> priorityReportData = new Dictionary<String, List<Int32>>();
        public static Dictionary<String, List<Int32>> tagReportData = new Dictionary<String, List<Int32>>();
        public static Dictionary<String, List<Int32>> suiteReportData = new Dictionary<String, List<Int32>>();
        
        private string folderName;
        private static string suiteTemplate;
        private static string tagTemplate;
        private static string allTestItems;
        private static string reportTemplate;
        private static string key;
        private static List<int> value;
        private static int total;
        private static string passPercent;

        public ReportTemplate(String _reportName, String _reportLocation)
        {
            // Initializing Objects


            reportName = _reportName;
            reportLocation = _reportLocation;
             folderName = _reportLocation + "\\" + _reportName + Utility.getCurrentDate("_") + "_" + Utility.getCurrentTime("_");
            reportPath = folderName + "\\" + _reportName + ".html";
            screenshotLocation = folderName + "\\screenshots";
            recordingsLocation = folderName + "\\recordings";

            Directory.CreateDirectory(folderName);
            Directory.CreateDirectory(screenshotLocation);
            Directory.CreateDirectory(recordingsLocation);

            startDate = Utility.getCurrentDate("/");
            startTime = Utility.getCurrentTime(":");
            endDate = startDate;
            endTime = startTime;

            counts.Add("parentCount", 0);
            counts.Add("passParent", 0);
            counts.Add("failParent", 0);

            counts.Add("childCount", 0);
            counts.Add("passChild", 0);
            counts.Add("failChild", 0);
            counts.Add("warningChild", 0);
            counts.Add("skipChild", 0);
            counts.Add("infoChild", 0);
            counts.Add("exceptionsChild", 0);

            counts.Add("passEvents", 0);
            counts.Add("failEvents", 0);
            counts.Add("otherEvents", 0);

            priorityReportData.Add("Low", new List<Int32> { 0, 0 });
            priorityReportData.Add("Medium", new List<Int32> { 0, 0 });
            priorityReportData.Add("High", new List<Int32> { 0, 0 });
            priorityReportData.Add("Critical", new List<Int32> { 0, 0 });

        }

        public static String getSuites()
        {
             suiteTemplate = "";
            foreach (String suite in suites)
            {
                suiteTemplate = suiteTemplate + $@"<a class=""dropdown-item"" href=""#"">{suite}</a>" + "\n";
            }
            return suiteTemplate;
        }

        public static String getTags()
        {
             tagTemplate = "";
            foreach (String tag in tags)
            {
                tagTemplate = tagTemplate + $@"<a class=""dropdown-item"" href=""#"">{tag}</a>" + "\n";
            }
            return tagTemplate;
        }

        public static String getTestItems()
        {
            allTestItems = "";
            foreach (KeyValuePair<String, TestItem> testItem in testItems)
            {
                allTestItems = allTestItems + testItem.Value.getTest() + "\n";
            }
            return allTestItems;
        }

        public static String getReport(Dictionary<String, List<Int32>> report)
        {
             reportTemplate = "";
            foreach (KeyValuePair<String, List<Int32>> row in report)
            {
                 key = row.Key;
                value = row.Value;
                 total = value[0] + value[1];
                 passPercent = "0";
                if (value[0] > 0)
                    passPercent = "" + (Math.Round(Convert.ToDouble(value[0]) / total, 2) * 100);
                reportTemplate += $@"
                <tr>
                    <td>{key}</td>
                    <td>{total}</td>
                    <td>{value[0]}</td>
                    <td>{value[1]}</td>
                    <td>{passPercent} %</td>
                </tr>
                ";
            }
            return reportTemplate;

        }

        public static void updateReport()
        {
             reportTemplate = "";
             reportTemplate = $@"
<!DOCTYPE html>
<html>
<head>
  <meta charset=""utf-8"">
  <meta name=""viewport"" content=""width=device-width, initial-scale=1, shrink-to-fit=no"">
  <title>Test Report</title>
 <link rel=""apple-touch-icon"" href=""https://img.icons8.com/cute-clipart/64/000000/investment-portfolio.png"">
	<link rel=""shortcut icon"" href=""https://img.icons8.com/cute-clipart/64/000000/investment-portfolio.png"">
<style type=""text/css""> .datetime{openingBrace}text-align: right;{closingBrace}.card-title{openingBrace}font-weight : bold;{closingBrace}.card{openingBrace}box-shadow: 14px 15px 16px -14px rgba(0,0,0,0.48);{closingBrace}
{Style.getStyle()}
</style></head> <script>
var JSONTree=function(){openingBrace}var n={openingBrace}""&"":""&amp;"",""<"":""&lt;"","">"":""&gt;"",'""':""&quot;"",""'"":""&#x27;"",""/"":""&#x2F;""{closingBrace},t=0,r=0;this.create=function(n,t){openingBrace}return r+=1,N(u(n,0,!1),{openingBrace}class:""jstValue""{closingBrace}){closingBrace};var e=function(t){openingBrace}return t.replace(/[&<>'""]/g,function(t){openingBrace}return n[t]{closingBrace}){closingBrace},s=function(){openingBrace}return r+""_""+t++{closingBrace},u=function(n,t,r){openingBrace}if(null===n)return f(r?t:0);switch(typeof n){openingBrace}case""boolean"":return l(n,r?t:0);case""number"":return i(n,r?t:0);case""string"":return o(n,r?t:0);default:return n instanceof Array?a(n,t,r):c(n,t,r){closingBrace}{closingBrace},c=function(n,t,r){openingBrace}var e=s(),u=Object.keys(n).map(function(r){openingBrace}return j(r,n[r],t+1,!0){closingBrace}).join(m()),c=[g(""{openingBrace}"",r?t:0,e),N(u,{openingBrace}id:e{closingBrace}),p(""{closingBrace}"",t)].join(""\n"");return N(c,{openingBrace}{closingBrace}){closingBrace},a=function(n,t,r){openingBrace}var e=s(),c=n.map(function(n){openingBrace}return u(n,t+1,!0){closingBrace}).join(m());return[g(""["",r?t:0,e),N(c,{openingBrace}id:e{closingBrace}),p(""]"",t)].join(""\n""){closingBrace},o=function(n,t){openingBrace}var r=e(JSON.stringify(n));return N(v(r,t),{openingBrace}class:""jstStr""{closingBrace}){closingBrace},i=function(n,t){openingBrace}return N(v(n,t),{openingBrace}class:""jstNum""{closingBrace}){closingBrace},l=function(n,t){openingBrace}return N(v(n,t),{openingBrace}class:""jstBool""{closingBrace}){closingBrace},f=function(n){openingBrace}return N(v(""null"",n),{openingBrace}class:""jstNull""{closingBrace}){closingBrace},j=function(n,t,r){openingBrace}var s=v(e(JSON.stringify(n))+"": "",r),c=N(u(t,r,!1),{openingBrace}{closingBrace});return N(s+c,{openingBrace}class:""jstProperty""{closingBrace}){closingBrace},m=function(){openingBrace}return N("",\n"",{openingBrace}class:""jstComma""{closingBrace}){closingBrace},N=function(n,t){openingBrace}return d(""span"",t,n){closingBrace},d=function(n,t,r){openingBrace}return""<""+n+Object.keys(t).map(function(n){openingBrace}return"" ""+n+'=""'+t[n]+'""'{closingBrace}).join("""")+"">""+r+""</""+n+"">""{closingBrace},g=function(n,t,r){openingBrace}return N(v(n,t),{openingBrace}class:""jstBracket""{closingBrace})+N("""",{openingBrace}class:""jstFold"",onclick:""JSONTree.toggle('""+r+""')""{closingBrace}){closingBrace};this.toggle=function(n){openingBrace}var t=document.getElementById(n),r=t.parentNode,e=t.previousElementSibling;""""===t.className?(t.className=""jstHiddenBlock"",r.className=""jstFolded"",e.className=""jstExpand""):(t.className="""",r.className="""",e.className=""jstFold""){closingBrace};var p=function(n,t){openingBrace}return N(v(n,t),{openingBrace}{closingBrace}){closingBrace},v=function(n,t){openingBrace}return Array(2*t+1).join("" "")+n{closingBrace};return this{closingBrace}();
</script>
<body class=""spa -report standard"">
  <div class=""app header-dark side-nav-folded"">
	<div class=""layout"">
<div class=""header navbar"">
  <div class=""header-container"">
    <ul class=""nav-left"">
	<li>
            <a class=""sidenav-fold-toggler"" href=""javascript:void(0);"">
              <svg width=""55px"" height=""50px"" style=""padding-left:20px;padding-top:5px;"">
  <defs>
    <linearGradient x1=""0.5"" y1=""1.00000012"" x2=""0.5"" y2=""0"" id=""RI_gradient_"">
      <stop offset=""0"" stop-color=""#41BFEC"" />
      <stop offset=""0.232"" stop-color=""#4CC5EF"" />
      <stop offset=""0.644"" stop-color=""#6BD4F6"" />
      <stop offset=""1"" stop-color=""#8AE4FD"" />
    </linearGradient>
    <linearGradient x1=""0.05971074"" y1=""0.9402894"" x2=""0.5742817"" y2=""0.425718337"" id=""gradient_2"">
      <stop offset=""0"" stop-color=""#C6EFFD"" />
      <stop offset=""0.375"" stop-color=""#B7ECFD"" />
      <stop offset=""1"" stop-color=""#95E6FD"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""1.01383352"" x2=""0.5"" y2=""0.0138335228"" id=""gradient_3"">
      <stop offset=""0"" stop-color=""#42C6EE"" />
      <stop offset=""0.48"" stop-color=""#3BC3ED"" />
      <stop offset=""1"" stop-color=""#2EBEEA"" />
    </linearGradient>
    <linearGradient x1=""0.5000125"" y1=""-0.26179564"" x2=""0.5000125"" y2=""0.8864852"" id=""gradient_4"">
      <stop offset=""0"" stop-color=""#A4A4A4"" />
      <stop offset=""0.63"" stop-color=""#7F7F7F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
  </defs>
  <g id=""report"" transform=""scale(0.7)"">
    <path d=""M37 52L3 52C1.343 52 0 50.657 0 49L0 3C0 1.343 1.343 0 3 0L23.757 0C24.553 0 25.316 0.316 25.878 0.879L39.121 14.122C39.684 14.684 40 15.447 40 16.243L40 25L44 34L40 41L40 49C40 50.657 38.657 52 37 52L37 52Z"" id=""Shape"" fill=""url(#RI_gradient_)"" stroke=""none"" />
    <path d=""M14.121 13.843L0.877998 0.6C0.622997 0.345 0.321999 0.148 0 0L0 11.721C0 13.378 1.343 14.721 3 14.721L14.721 14.721C14.574 14.399 14.377 14.098 14.121 13.843L14.121 13.843Z"" transform=""translate(25 0.2789917)"" id=""Shape"" fill=""url(#gradient_2)"" stroke=""none"" />
    <path d=""M3 3C1.343 3 0 1.657 0 0L0 3C0 4.657 1.343 6 3 6L15 6L15 4.243C15 3.809 14.898 3.388 14.721 3L3 3L3 3Z"" transform=""translate(25 12)"" id=""Shape"" fill=""url(#gradient_3)"" stroke=""none"" />
    <path d=""M13 4L2 4C0.895001 4 0 3.105 0 2L0 2C0 0.895 0.895001 0 2 0L13 0C14.105 0 15 0.895 15 2L15 2C15 3.105 14.105 4 13 4L13 4Z"" transform=""translate(6 12)"" id=""Shape"" fill=""#F1FCFF"" stroke=""none"" />
    <g id=""Group"" transform=""translate(6 31)"">
      <path d=""M2 0L16 0C17.105 0 18 0.895 18 2L18 2C18 3.105 17.105 4 16 4L2 4C0.895 4 0 3.105 0 2L0 2C0 0.895 0.895 0 2 0L2 0Z"" id=""Shape"" fill=""#F1FCFF"" stroke=""none"" />
    </g>
    <g id=""Group"" transform=""translate(6 23)"">
      <path d=""M21 0L2 0C0.895 0 0 0.895 0 2C0 3.105 0.895 4 2 4L21 4C22.105 4 23 3.105 23 2C23 0.895 22.105 0 21 0ZM2 20L11 20C12.105 20 13 19.105 13 18C13 16.895 12.105 16 11 16L2 16C0.895 16 0 16.895 0 18C0 19.105 0.895 20 2 20Z"" id=""Shape"" fill=""#F1FCFF"" fill-rule=""evenodd"" stroke=""none"" />
    </g>
    <g id=""Group"" transform=""translate(23.12 27)"">
      <path d=""M11.38 0L2.501 0C1.12 0 0.000999451 1.119 0.000999451 2.5L0.000999451 5L11.38 5C12.761 5 13.88 3.881 13.88 2.5C13.88 1.119 12.761 0 11.38 0ZM11.38 10L0 10L0 12.5C0 13.881 1.119 15 2.5 15L11.38 15C12.761 15 13.88 13.881 13.88 12.5C13.88 11.119 12.761 10 11.38 10Z"" id=""Shape"" fill=""#F1FCFF"" fill-rule=""evenodd"" stroke=""none"" />
    </g>
    <path d=""M22.631 19.802L29.417 26.588C30.194 27.366 30.193 28.639 29.416 29.417C28.639 30.195 27.366 30.195 26.588 29.417L19.802 22.631C17.747 24.115 15.229 25 12.5 25C5.596 25 0 19.404 0 12.5C0 5.596 5.596 0 12.5 0C19.404 0 25 5.596 25 12.5C25 15.229 24.115 17.747 22.631 19.802ZM12.5 4C7.806 4 4 7.806 4 12.5C4 17.194 7.806 21 12.5 21C17.194 21 21 17.194 21 12.5C21 7.806 17.194 4 12.5 4Z"" transform=""translate(21 21)"" id=""Shape"" fill=""url(#gradient_4)"" fill-rule=""evenodd"" stroke=""none"" />
  </g>
</svg>
            </a>
            <a class=""sidenav-expand-toggler"" href=""javascript:void(0);"">
               <svg width=""55px"" height=""50px"" style=""padding-left:20px;padding-top:5px;"">
  <defs>
    <linearGradient x1=""0.5"" y1=""1.00000012"" x2=""0.5"" y2=""0"" id=""RI_gradient_"">
      <stop offset=""0"" stop-color=""#41BFEC"" />
      <stop offset=""0.232"" stop-color=""#4CC5EF"" />
      <stop offset=""0.644"" stop-color=""#6BD4F6"" />
      <stop offset=""1"" stop-color=""#8AE4FD"" />
    </linearGradient>
    <linearGradient x1=""0.05971074"" y1=""0.9402894"" x2=""0.5742817"" y2=""0.425718337"" id=""gradient_2"">
      <stop offset=""0"" stop-color=""#C6EFFD"" />
      <stop offset=""0.375"" stop-color=""#B7ECFD"" />
      <stop offset=""1"" stop-color=""#95E6FD"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""1.01383352"" x2=""0.5"" y2=""0.0138335228"" id=""gradient_3"">
      <stop offset=""0"" stop-color=""#42C6EE"" />
      <stop offset=""0.48"" stop-color=""#3BC3ED"" />
      <stop offset=""1"" stop-color=""#2EBEEA"" />
    </linearGradient>
    <linearGradient x1=""0.5000125"" y1=""-0.26179564"" x2=""0.5000125"" y2=""0.8864852"" id=""gradient_4"">
      <stop offset=""0"" stop-color=""#A4A4A4"" />
      <stop offset=""0.63"" stop-color=""#7F7F7F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
  </defs>
  <g id=""report"" transform=""scale(0.7)"">
    <path d=""M37 52L3 52C1.343 52 0 50.657 0 49L0 3C0 1.343 1.343 0 3 0L23.757 0C24.553 0 25.316 0.316 25.878 0.879L39.121 14.122C39.684 14.684 40 15.447 40 16.243L40 25L44 34L40 41L40 49C40 50.657 38.657 52 37 52L37 52Z"" id=""Shape"" fill=""url(#RI_gradient_)"" stroke=""none"" />
    <path d=""M14.121 13.843L0.877998 0.6C0.622997 0.345 0.321999 0.148 0 0L0 11.721C0 13.378 1.343 14.721 3 14.721L14.721 14.721C14.574 14.399 14.377 14.098 14.121 13.843L14.121 13.843Z"" transform=""translate(25 0.2789917)"" id=""Shape"" fill=""url(#gradient_2)"" stroke=""none"" />
    <path d=""M3 3C1.343 3 0 1.657 0 0L0 3C0 4.657 1.343 6 3 6L15 6L15 4.243C15 3.809 14.898 3.388 14.721 3L3 3L3 3Z"" transform=""translate(25 12)"" id=""Shape"" fill=""url(#gradient_3)"" stroke=""none"" />
    <path d=""M13 4L2 4C0.895001 4 0 3.105 0 2L0 2C0 0.895 0.895001 0 2 0L13 0C14.105 0 15 0.895 15 2L15 2C15 3.105 14.105 4 13 4L13 4Z"" transform=""translate(6 12)"" id=""Shape"" fill=""#F1FCFF"" stroke=""none"" />
    <g id=""Group"" transform=""translate(6 31)"">
      <path d=""M2 0L16 0C17.105 0 18 0.895 18 2L18 2C18 3.105 17.105 4 16 4L2 4C0.895 4 0 3.105 0 2L0 2C0 0.895 0.895 0 2 0L2 0Z"" id=""Shape"" fill=""#F1FCFF"" stroke=""none"" />
    </g>
    <g id=""Group"" transform=""translate(6 23)"">
      <path d=""M21 0L2 0C0.895 0 0 0.895 0 2C0 3.105 0.895 4 2 4L21 4C22.105 4 23 3.105 23 2C23 0.895 22.105 0 21 0ZM2 20L11 20C12.105 20 13 19.105 13 18C13 16.895 12.105 16 11 16L2 16C0.895 16 0 16.895 0 18C0 19.105 0.895 20 2 20Z"" id=""Shape"" fill=""#F1FCFF"" fill-rule=""evenodd"" stroke=""none"" />
    </g>
    <g id=""Group"" transform=""translate(23.12 27)"">
      <path d=""M11.38 0L2.501 0C1.12 0 0.000999451 1.119 0.000999451 2.5L0.000999451 5L11.38 5C12.761 5 13.88 3.881 13.88 2.5C13.88 1.119 12.761 0 11.38 0ZM11.38 10L0 10L0 12.5C0 13.881 1.119 15 2.5 15L11.38 15C12.761 15 13.88 13.881 13.88 12.5C13.88 11.119 12.761 10 11.38 10Z"" id=""Shape"" fill=""#F1FCFF"" fill-rule=""evenodd"" stroke=""none"" />
    </g>
    <path d=""M22.631 19.802L29.417 26.588C30.194 27.366 30.193 28.639 29.416 29.417C28.639 30.195 27.366 30.195 26.588 29.417L19.802 22.631C17.747 24.115 15.229 25 12.5 25C5.596 25 0 19.404 0 12.5C0 5.596 5.596 0 12.5 0C19.404 0 25 5.596 25 12.5C25 15.229 24.115 17.747 22.631 19.802ZM12.5 4C7.806 4 4 7.806 4 12.5C4 17.194 7.806 21 12.5 21C17.194 21 21 17.194 21 12.5C21 7.806 17.194 4 12.5 4Z"" transform=""translate(21 21)"" id=""Shape"" fill=""url(#gradient_4)"" fill-rule=""evenodd"" stroke=""none"" />
  </g>
</svg>
            </a>
    </li>
     <li class=""search-box"">
      <a class=""search-toggle"" href=""javascript:void(0);"">
       <i class=""search-icon"">
	   <svg height=""40"" width=""30"" style=""padding-top:18px"">
     <g id=""search"" transform=""scale(0.40)"">
    <path d=""M49.846 43.998L49.852 43.992L37.621 31.761C39.752 28.528 41 24.662 41 20.5C41 9.178 31.822 0 20.5 0C9.178 0 0 9.178 0 20.5C0 31.822 9.178 41 20.5 41C24.663 41 28.531 39.751 31.765 37.619L43.997 49.848C45.539 51.39 48.037 51.39 49.578 49.848L49.846 49.58C51.385 48.038 51.385 45.54 49.846 43.998L49.846 43.998Z"" id=""Shape"" fill=""#FFFFFF"" stroke=""none"" />
    <path d=""M14.5 0C6.49187 0 0 6.49187 0 14.5C9.53674e-07 22.5081 6.49187 29 14.5 29C22.5081 29 29 22.5081 29 14.5C29 6.49187 22.5081 0 14.5 0L14.5 0Z"" transform=""translate(6 6)"" id=""Shape"" fill=""#334A65"" stroke=""none"" />
  </g>
  search
</svg>
	   </i>
       <i class=""search-icon-close""  onClick=""attrToggle()"">
        <svg height=""40"" width=""30"" style=""padding-top:20px"">
     <g id=""White-cross"" transform=""scale(0.40)"">
    <path d=""M40.937 1.05725L40.94 1.06025C42.353 2.47225 42.354 4.76225 40.941 6.17425L6.171 40.9382C4.759 42.3503 2.47 42.3503 1.059 40.9382L1.059 40.9382C-0.353 39.5263 -0.353 37.2373 1.059 35.8252L35.825 1.05925C37.237 -0.35275 39.525 -0.35275 40.937 1.05725L40.937 1.05725Z"" transform=""translate(0 0.003753662)"" id=""Shape"" fill=""#FFFFFF"" stroke=""none"" />
    <path d=""M40.9372 40.947L40.9372 40.947C39.5252 42.359 37.2362 42.359 35.8242 40.947L1.05825 6.171C-0.35275 4.759 -0.35275 2.47 1.05825 1.059L1.05825 1.059C2.47025 -0.353 4.75925 -0.353 6.17125 1.059L40.9372 35.835C42.3493 37.247 42.3493 39.536 40.9372 40.947L40.9372 40.947Z"" id=""Shape"" fill=""#FFFFFF"" stroke=""none"" />
  </g>
  Close
</svg>
	   </i>
      </a>
     </li>
     <li class=""search-input"">
      <input id=""search-tests"" class=""form-control"" type=""text"" placeholder=""Type to search..."">
     </li>
    </ul>
    <ul class=""nav-right"">
     <li class=""m-r-10"">
      <a href=""#"">
       <span class=""badge badge-primary"">{reportName}</span>
      </a>
     </li>
      <li class=""m-r-10"">
        <a href=""#"">
          <span class=""badge badge-primary"">{startDate + " " + startTime}</span>
        </a>
      </li>
    </ul>
  </div>
</div><div class=""side-nav side-nav-folded"">
 <div class=""side-nav-inner"">
  <ul class=""side-nav-menu scrollable"">
   <li class=""nav-item dropdown"" onclick=""toggleView('dashboard-view')"">
    <a id=""nav-dashboard"" class=""dropdown-toggle"" href=""dashboard.html"">
     <span class=""icon-holder"">
     <svg height=""30"" width=""30"" >
 <defs>
    <linearGradient x1=""0.5"" y1=""1.16968"" x2=""0.5"" y2=""0.16968"" id=""D_gradient_1"">
      <stop offset=""0"" stop-color=""#3CB5EA"" />
      <stop offset=""1"" stop-color=""#7DDEFB"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.9999999"" x2=""0.5"" y2=""-2.74180532"" id=""D_gradient_2"">
      <stop offset=""0"" stop-color=""#0D47A1"" />
      <stop offset=""0.365"" stop-color=""#135FBA"" />
      <stop offset=""0.734"" stop-color=""#1770CC"" />
      <stop offset=""1"" stop-color=""#1976D2"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""1"" x2=""0.5"" y2=""0"" id=""D_gradient_3"">
      <stop offset=""0"" stop-color=""#2D8FE8"" />
      <stop offset=""1"" stop-color=""#3BB5F1"" />
    </linearGradient>
  </defs>
  <g id=""dashboard1""  transform=""scale(0.60)"">
    <path d=""M50 25C50 38.805 38.805 50 25 50C11.195 50 0 38.805 0 25C0 11.195 11.195 0 25 0C38.805 0 50 11.195 50 25L50 25Z"" id=""Shape"" fill=""url(#D_gradient_1)"" stroke=""none"" />
    <path d=""M0 0L18.197 17.084C22.363 12.641 25 6.668 25 0L0 0L0 0Z"" transform=""translate(25 25)"" id=""Shape"" fill=""url(#D_gradient_2)"" stroke=""none"" />
    <path d=""M25 25C25 11.252 13.748 0 0 0L0 25L25 25L25 25Z"" transform=""translate(25 0)"" id=""Shape"" fill=""url(#D_gradient_3)"" stroke=""none"" />
  </g>
/>
Dashboard
</svg>
     </span>
    </a>
   </li>
  <li class=""nav-item dropdown"" onclick=""toggleView('test-view')"">
    <a id=""nav-test"" class=""dropdown-toggle"" href=""index.html"">
     <span class=""icon-holder"">
     <svg height=""30"" width=""30"">
  <defs>
    <linearGradient x1=""0.5"" y1=""1.15287185"" x2=""0.5"" y2=""-0.47307694"" id=""gradient_1"">
      <stop offset=""0"" stop-color=""#155CDE"" />
      <stop offset=""0.158"" stop-color=""#196CE1"" />
      <stop offset=""0.724"" stop-color=""#28A1EC"" />
      <stop offset=""1"" stop-color=""#2EB5F0"" />
    </linearGradient>
  </defs>
  <path d=""M6 3C6 1.35 4.65 0 3 0C1.35 0 0 1.35 0 3C0 4.65 1.35 6 3 6C4.65 6 6 4.65 6 3ZM40 6L12 6C10.35 6 9 4.65 9 3C9 1.35 10.35 0 12 0L40 0C41.65 0 43 1.35 43 3C43 4.65 41.65 6 40 6ZM6 14C6 12.35 4.65 11 3 11C1.35 11 0 12.35 0 14C0 15.65 1.35 17 3 17C4.65 17 6 15.65 6 14ZM43 14C43 12.35 41.65 11 40 11L12 11C10.35 11 9 12.35 9 14C9 15.65 10.35 17 12 17L40 17C41.65 17 43 15.65 43 14ZM3 22C4.65 22 6 23.35 6 25C6 26.65 4.65 28 3 28C1.35 28 0 26.65 0 25C0 23.35 1.35 22 3 22ZM40 22C41.65 22 43 23.35 43 25C43 26.65 41.65 28 40 28L12 28C10.35 28 9 26.65 9 25C9 23.35 10.35 22 12 22L40 22ZM3 33C4.65 33 6 34.35 6 36C6 37.65 4.65 39 3 39C1.35 39 0 37.65 0 36C0 34.35 1.35 33 3 33ZM40 33C41.65 33 43 34.35 43 36C43 37.65 41.65 39 40 39L12 39C10.35 39 9 37.65 9 36C9 34.35 10.35 33 12 33L40 33Z"" id=""Shape"" fill=""url(#gradient_1)"" fill-rule=""evenodd"" stroke=""none""
transform=""scale(0.6)""  
/>
Tests.
</svg>
     </span>
    </a>
   </li>
  </ul>
 </div>
</div> <div class=""page-container"">
        <div class=""main-content"">
<div class=""test-wrapper row test-view"">
 <div class=""test-list"">
 <div class=""test-list-tools"">
			<ul class=""tools"" style=""float:left;padding-top:7px;"">
				<li>
					<span class=""font-size-14"">Total Tests : <b id=""testCount"">0</b></span>
				</li>
			</ul>
			<ul class=""tools text-right"">
				<li>
					<a href=""#"" id=""clear-filter"">
					<span>
	  <svg height=""25"" width=""25"" style=""padding-top:7px"">
    <defs>
    <linearGradient x1=""0.5"" y1=""1"" x2=""0.5"" y2=""0"" id=""CA_gradient_1"">
      <stop offset=""0"" stop-color=""#FF634D"" />
      <stop offset=""0.204"" stop-color=""#FE6464"" />
      <stop offset=""0.521"" stop-color=""#FC6581"" />
      <stop offset=""0.794"" stop-color=""#FA6694"" />
      <stop offset=""0.989"" stop-color=""#FA669A"" />
      <stop offset=""1"" stop-color=""#FA669A"" />
    </linearGradient>
  </defs>
  <g id=""clear-all"" transform=""scale(0.4),matrix(-1 0 0 1 56 0)"">
    <path d=""M1.456 21.371L15.267 34.369C16.38 35.417 17.851 36 19.379 36L53 36C54.657 36 56 34.657 56 33L56 3C56 1.343 54.657 0 53 0L19.38 0C17.852 0 16.381 0.583 15.268 1.631L1.456 14.629C0.527 15.504 0 16.724 0 18C0 19.276 0.527 20.496 1.456 21.371L1.456 21.371Z"" transform=""translate(0 3.051758E-05)"" id=""Shape"" fill=""url(#CA_gradient_1)"" stroke=""none"" />
    <g id=""Group"" transform=""translate(22 7.000023)"">
      <path d=""M21.268 0.732L21.268 0.732C22.244 1.708 22.244 3.291 21.268 4.267L4.267 21.268C3.291 22.244 1.708 22.244 0.732 21.268L0.732 21.268C-0.243999 20.292 -0.243999 18.709 0.732 17.733L17.733 0.732002C18.709 -0.243999 20.292 -0.243999 21.268 0.732L21.268 0.732Z"" id=""Shape"" fill=""#EEEEEE"" stroke=""none"" />
      <path d=""M21.268 21.268L21.268 21.268C20.292 22.244 18.709 22.244 17.733 21.268L0.732 4.267C-0.243999 3.291 -0.243999 1.708 0.732 0.732L0.732 0.732C1.708 -0.243999 3.291 -0.243999 4.267 0.732L21.268 17.733C22.244 18.709 22.244 20.292 21.268 21.268L21.268 21.268Z"" id=""Shape"" fill=""#EEEEEE"" stroke=""none"" />
    </g>
  </g>
  Clear All
</svg>
	</span>
					</a>
				</li>
				<li class=""user-profile dropdown dropdown-animated scale-left"">
					 <a id=""ID_Status"" href=""#"" class=""dropdown-toggle"" data-toggle=""dropdown"" style="""">
   <svg height=""28"" width=""17"" style=""padding-top:5px"">
   <defs>
    <linearGradient x1=""0.5"" y1=""1.01871419"" x2=""0.5"" y2=""0.0187142789"" id=""PF_gradient_1"">
      <stop offset=""0"" stop-color=""#FF8B67"" />
      <stop offset=""0.847"" stop-color=""#FFA76A"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""-0.0431025624"" x2=""0.5"" y2=""1.09997427"" id=""PF_gradient_2"">
      <stop offset=""0"" stop-color=""#FFCFA2"" />
      <stop offset=""1"" stop-color=""#FFD17C"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0"" x2=""0.5"" y2=""1"" id=""PF_gradient_3"">
      <stop offset=""0"" stop-color=""#FFF1E3"" />
      <stop offset=""1"" stop-color=""#FFF1D8"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.019125"" x2=""0.5"" y2=""1.3295"" id=""PF_gradient_4"">
      <stop offset=""0"" stop-color=""#ADADAD"" />
      <stop offset=""0.412"" stop-color=""#969696"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
    <linearGradient x1=""0.5000001"" y1=""1.08022237"" x2=""0.5000001"" y2=""-0.3283888"" id=""PF_gradient_5"">
      <stop offset=""0"" stop-color=""#F29265"" />
      <stop offset=""1"" stop-color=""#F9AE7F"" />
    </linearGradient>
    <linearGradient x1=""0.500000238"" y1=""-5.507469E-05"" x2=""0.500000238"" y2=""0.99991703"" id=""PF_gradient_6"">
      <stop offset=""0"" stop-color=""#40D277"" />
      <stop offset=""0.704"" stop-color=""#38BC73"" />
      <stop offset=""1"" stop-color=""#34B171"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.999949932"" x2=""0.5"" y2=""-5.00679E-05"" id=""PF_gradient_7"">
      <stop offset=""0"" stop-color=""#FF5840"" />
      <stop offset=""0.007"" stop-color=""#FF5840"" />
      <stop offset=""0.989"" stop-color=""#FA528C"" />
      <stop offset=""1"" stop-color=""#FA528C"" />
    </linearGradient>
  </defs>
  <g id=""PassFail"" transform=""scale(0.4)"">
    <path d=""M35 0L24 0C24 2.209 22.209 4 20 4C17.791 4 16 2.209 16 0L5 0C2.25 0 0 2.25 0 5L0 44C0 46.75 2.25 49 5 49L35 49C37.75 49 40 46.75 40 44L40 5C40 2.25 37.75 0 35 0L35 0Z"" transform=""translate(0 7)"" id=""Shape"" fill=""url(#PF_gradient_1)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PF_gradient_2)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PF_gradient_3)"" stroke=""none"" />
    <path d=""M11 0C14.866 0 18 3.134 18 7L22 7L22 13C22 14.657 20.657 16 19 16L3 16C1.343 16 0 14.657 0 13L0 7L4 7C4 3.134 7.134 0 11 0ZM8 7C8 8.657 9.343 10 11 10C12.657 10 14 8.657 14 7C14 5.343 12.657 4 11 4C9.343 4 8 5.343 8 7Z"" transform=""translate(9 0)"" id=""Shape"" fill=""url(#PF_gradient_4)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M9 4C10.105 4 11 3.105 11 2C11 0.895 10.105 0 9 0L2 0C0.895 0 0 0.895 0 2C0 3.105 0.895 4 2 4L9 4ZM9 18C10.105 18 11 17.105 11 16C11 14.895 10.105 14 9 14L2 14C0.895 14 0 14.895 0 16C0 17.105 0.895 18 2 18L9 18Z"" transform=""translate(8 24)"" id=""Shape"" fill=""url(#PF_gradient_5)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M12 1.9975C12 2.5075 11.8 3.0175 11.42 3.4075L7.83 6.9975L6.414 8.4135C5.633 9.1945 4.367 9.1945 3.586 8.4135L0.580002 5.4075C0.200001 5.0175 0 4.5075 0 3.9975C0 3.4775 0.200001 2.9675 0.580002 2.5775C1.36 1.8075 2.63 1.8075 3.41 2.5775L5 4.1675L8.59 0.577501C9.37 -0.192499 10.64 -0.192499 11.42 0.577501C11.8 0.966503 12 1.4765 12 1.9975L12 1.9975Z"" transform=""translate(21 21.0005)"" id=""Shape"" fill=""url(#PF_gradient_6)"" stroke=""none"" />
    <path d=""M7.8275 5.0005L9.4155 3.4125C10.1935 2.6345 10.1935 1.3615 9.4155 0.584499C8.6375 -0.193501 7.3645 -0.193501 6.5875 0.584499L4.9995 2.1715L3.4115 0.5835C2.6335 -0.1945 1.3605 -0.1945 0.5835 0.5835C-0.1945 1.3615 -0.1945 2.6345 0.5835 3.4115L2.1715 5.0005L0.5835 6.5885C-0.1945 7.3665 -0.1945 8.6395 0.5835 9.4165C1.3615 10.1935 2.6345 10.1945 3.4115 9.4165L4.9995 7.8285L6.5875 9.4165C7.3655 10.1945 8.6385 10.1945 9.4155 9.4165C10.1925 8.6385 10.1935 7.3655 9.4155 6.5885L7.8275 5.0005L7.8275 5.0005Z"" transform=""translate(22.00049 34.9995)"" id=""Shape"" fill=""url(#PF_gradient_7)"" stroke=""none"" />
  </g>
PassFail
</svg>
   </a>
					<ul id=""status-toggle"" class=""dropdown-menu dropdown-md p-v-0"">
						<a class=""dropdown-item"" status=""pass"" href=""#""><span>Pass</span></a>
						<a class=""dropdown-item"" status=""fail"" href=""#""><span>Fail</span></a>
						<div class=""dropdown-divider""></div>
						<a status=""clear"" class=""dropdown-item"" href=""#""><span>Clear</span><span style=""float:right"">&#128473;</span></a>
					</ul>
				</li>
				<li class=""user-profile dropdown dropdown-animated scale-left"">
					<a id=""ID_Suite"" href=""#"" class=""dropdown-toggle"" data-toggle=""dropdown"" style="""">
   <svg height=""25"" width=""23"" style=""padding-top:5px"">
  <defs>
    <linearGradient x1=""0.5"" y1=""0.99999994"" x2=""0.5"" y2=""0"" id=""S_gradient_1"">
      <stop offset=""0"" stop-color=""#FF9757"" />
      <stop offset=""1"" stop-color=""#FFB65B"" />
      <stop offset=""1"" stop-color=""#FFB65B"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.935"" x2=""0.5"" y2=""-0.6223044"" id=""S_gradient_2"">
      <stop offset=""0"" stop-color=""#F29265"" />
      <stop offset=""0.64"" stop-color=""#FBB687"" />
      <stop offset=""1"" stop-color=""#FFC595"" />
    </linearGradient>
  </defs>
  <g id=""svg"" transform=""scale(0.40)"">
    <path d=""M16.5 11.5C15.672 11.5 15 10.829 15 10L15 5.5C15 4.122 13.654 3 12 3L6 3C4.346 3 3 4.122 3 5.5L3 10C3 10.829 2.328 11.5 1.5 11.5C0.672001 11.5 0 10.829 0 10L0 5.5C0 2.467 2.691 0 6 0L12 0C15.309 0 18 2.467 18 5.5L18 10C18 10.829 17.328 11.5 16.5 11.5L16.5 11.5Z"" transform=""translate(19 0)"" id=""Shape"" fill=""#717171"" stroke=""none"" />
    <path d=""M50 41L6 41C2.686 41 0 38.314 0 35L0 6C0 2.686 2.686 0 6 0L50 0C53.314 0 56 2.686 56 6L56 35C56 38.314 53.314 41 50 41L50 41Z"" transform=""translate(0 7)"" id=""Shape"" fill=""url(#S_gradient_1)"" stroke=""none"" />
    <path d=""M51 23L5 23C2.239 23 0 20.761 0 18L0 6C0 2.686 2.686 0 6 0L50 0C53.314 0 56 2.686 56 6L56 18C56 20.761 53.761 23 51 23L51 23Z"" transform=""translate(0 7)"" id=""Shape"" fill=""url(#S_gradient_2)"" stroke=""none"" />
    <path d=""M8 6L2 6C0.895 6 0 5.105 0 4L0 2C0 0.895 0.895 0 2 0L8 0C9.105 0 10 0.895 10 2L10 4C10 5.105 9.105 6 8 6L8 6Z"" transform=""translate(23 21)"" id=""Shape"" fill=""#FFF3E0"" stroke=""none"" />
  </g>
Suite
</svg>
   </a>
					<ul id=""author-toggle"" class=""dropdown-menu dropdown-md p-v-0"">
						{getSuites()}
						<div class=""dropdown-divider""></div>
						<a status=""clear"" class=""dropdown-item"" href=""#""><span>Clear</span><span style=""float:right"">&#128473;</span></a>
					</ul>
				</li>
				<li class=""user-profile dropdown dropdown-animated scale-left"">
					<a id=""ID_Tag"" href=""#"" class=""dropdown-toggle"" data-toggle=""dropdown"" style="""">
   <svg height=""25"" width=""25"" >
  <path d=""M40.733 1.631L54.544 14.629C55.473 15.504 56 16.724 56 18C56 19.276 55.473 20.496 54.543 21.371L40.732 34.369C39.619 35.417 38.148 36 36.62 36L3 36C1.343 36 0 34.657 0 33L0 3C0 1.343 1.343 0 3 0L36.621 0C38.149 0 39.62 0.583 40.733 1.631ZM43 17.9999C43 19.6569 44.343 20.9999 46 20.9999C47.657 20.9999 49 19.6569 49 17.9999C49 16.3429 47.657 14.9999 46 14.9999C44.343 14.9999 43 16.3429 43 17.9999Z"" 
 transform=""scale(0.40),matrix(-0.6427875 -0.7660445 0.7660445 -0.6427875 35.99609 66.03883)"" 
 fill=""#FFC050""
 />
 Tag
</svg>
   </a>
					<ul id=""tag-toggle"" class=""dropdown-menu dropdown-md p-v-0"">
						{getTags()}
						<div class=""dropdown-divider""></div>
						<a status=""clear"" class=""dropdown-item"" href=""#""><span>Clear</span><span style=""float:right"">&#128473;</span></a>
					</ul>
				</li>
				<li class=""user-profile dropdown dropdown-animated scale-left"">
					<a id=""ID_Priority"" href=""#"" class=""dropdown-toggle"" data-toggle=""dropdown"" style="""">
   <svg height=""25"" width=""23"" style=""padding-top:6px"">
     <defs>
    <linearGradient x1=""0.4999985"" y1=""0.7811136"" x2=""0.4999985"" y2=""-0.73786366"" id=""P_gradient_1"">
      <stop offset=""0"" stop-color=""#FF9757"" />
      <stop offset=""1"" stop-color=""#FFB65B"" />
      <stop offset=""1"" stop-color=""#FFB65B"" />
    </linearGradient>
  </defs>
  <g id=""Priority"" transform=""scale(0.4)"">
    <path d=""M0.515127 38.199L21.4821 1.734C22.0991 0.661 23.2421 0 24.4791 0L24.4791 0C25.7161 0 26.8591 0.661 27.4761 1.734L48.4431 38.199C49.0901 39.324 49.1301 40.698 48.5501 41.859L48.5491 41.861C47.8931 43.172 46.5531 44 45.0871 44L3.87113 44C2.40513 44 1.06513 43.172 0.410127 41.861L0.409127 41.859C-0.171873 40.698 -0.131873 39.324 0.515127 38.199L0.515127 38.199Z"" id=""Shape"" fill=""url(#P_gradient_1)"" stroke=""none"" />
    <path d=""M0 3C0 1.343 1.343 0 3 0C4.657 0 6 1.343 6 3L5.133 16.004C5.058 17.127 4.125 18 3 18C1.875 18 0.941999 17.127 0.867001 16.004L0 3ZM3 25C4.105 25 5 24.105 5 23C5 21.895 4.105 21 3 21C1.895 21 1 21.895 1 23C1 24.105 1.895 25 3 25Z"" transform=""translate(21.47913 14)"" id=""Shape"" fill=""#EEEEEE"" fill-rule=""evenodd"" stroke=""none"" />
  </g>
  Priority
</svg>
   </a>
					<ul id=""priority-toggle"" class=""dropdown-menu dropdown-md p-v-0"">
						<a status=""element"" class=""dropdown-item"" href=""#"">Low</a>
						<a status=""element"" class=""dropdown-item"" href=""#"">Medium</a>
						<a status=""element"" class=""dropdown-item"" href=""#"">High</a>
						<a status=""element"" class=""dropdown-item"" href=""#"">Critical</a>
						<div class=""dropdown-divider""></div>
						<a status=""clear"" class=""dropdown-item"" href=""#""><span>Clear</span><span style=""float:right"">&#128473;</span></a>
					</ul>
				</li>
			</ul>
 </div>
 <div class=""test-list-wrapper scrollable"">
  <ul class=""test-list-item""><!--TestStatus1-->
	{getTestItems()}
  </ul>
 </div>
 </div>
 <div class=""test-content scrollable"">
 <div class=""test-content-tools"">
  <ul>
  <li>
   <a class=""back-to-test"" href=""javascript:void(0)"">
    &#128473;
   </a>
  </li>
  </ul>
 </div>
 <div class=""test-content-detail"">
  <div class=""detail-body""></div>
 </div>
 </div>
 <!-- dashboard -->
</div><div class=""container-fluid p-4 dashboard-view"">
 <div class=""row"">
 <div class=""col-sm-12 col-md-4"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Tests</h6>
  </div>
  <div class=""card-body"">
   <div class="""">
   <canvas id='parent-analysis' width='115' height='90'></canvas>
   </div>
  </div>
  <div class=""card-footer"">
   <div><small>
   <b>{counts["passParent"]}</b> tests passed
   </small>
   </div>
   <div>
   <small><b>{counts["failParent"]}</b> tests failed
   </small>
   </div>
  </div>
  </div>
 </div>
 <div class=""col-sm-12 col-md-4"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Steps</h6>
  </div>
  <div class=""card-body"">
   <div class="""">
   <canvas id='child-analysis' width='115' height='90'></canvas>
   </div>
  </div>
  <div class=""card-footer"">
   <div><small><b>{counts["passChild"]}</b> steps passed, <b>{counts["failChild"]}</b> steps failed, <b>{counts["skipChild"]}</b> steps skipped, <b>{counts["exceptionsChild"]}</b> steps has exception</small></div>
   <div>
   <small><b>{counts["warningChild"]}</b> steps has warning, <b>{counts["infoChild"]}</b> info steps</small>
   </div>
  </div>
  </div>
 </div>
 <div class=""col-sm-12 col-md-4"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Log events</h6>
  </div>
  <div class=""card-body"">
   <div class="""">
   <canvas id='events-analysis' width='115' height='90'></canvas>
   </div>
  </div>
  <div class=""card-footer"">
   <div><small><b>{counts["passEvents"]}</b> events passed</small></div>
   <div>
   <small><b> {counts["failEvents"]}</b> events failed,
   <b>{counts["otherEvents"]}</b> others
   </small>
   </div>
  </div>
  </div>
 </div>
 </div>
 <div class=""row"">
 <div class=""col-md-3"">
  <div class=""card"">
  <div class=""card-body box-height-150"">
   <div class=""media justify-content-between"">
   <div class=""card-header"">
    <h6 class=""card-title"">Total Tests</h6>
    <h2 class=""font-size-28 font-weight-light mt-3"">{counts["parentCount"]}</h2>
    <span class=""text-semibold text-success font-size-15"">
    <i class=""ti-arrow-up font-size-11""></i>
    <span>{ ((counts["passParent"] > 0) ? (Math.Round((Convert.ToDouble(counts["passParent"]) / counts["parentCount"]), 2) * 100) : 0)}%</span>
    </span>
   </div>
   <div class=""align-self-end"">
    <svg height=""100"" width=""80"" >
     <defs>
    <linearGradient x1=""0.5"" y1=""1.01871419"" x2=""0.5"" y2=""0.0187142789"" id=""PP_gradient_1"">
      <stop offset=""0"" stop-color=""#FF8B67"" />
      <stop offset=""0.847"" stop-color=""#FFA76A"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""-0.0431025624"" x2=""0.5"" y2=""1.09997427"" id=""PP_gradient_2"">
      <stop offset=""0"" stop-color=""#FFCFA2"" />
      <stop offset=""1"" stop-color=""#FFD17C"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0"" x2=""0.5"" y2=""1"" id=""PP_gradient_3"">
      <stop offset=""0"" stop-color=""#FFF1E3"" />
      <stop offset=""1"" stop-color=""#FFF1D8"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.019125"" x2=""0.5"" y2=""1.3295"" id=""PP_gradient_4"">
      <stop offset=""0"" stop-color=""#ADADAD"" />
      <stop offset=""0.412"" stop-color=""#969696"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
    <linearGradient x1=""0.5000001"" y1=""1.08022237"" x2=""0.5000001"" y2=""-0.3283888"" id=""PP_gradient_5"">
      <stop offset=""0"" stop-color=""#F29265"" />
      <stop offset=""1"" stop-color=""#F9AE7F"" />
    </linearGradient>
    <linearGradient x1=""0.500000238"" y1=""-5.507469E-05"" x2=""0.500000238"" y2=""0.99991703"" id=""PP_gradient_6"">
      <stop offset=""0"" stop-color=""#40D277"" />
      <stop offset=""0.704"" stop-color=""#38BC73"" />
      <stop offset=""1"" stop-color=""#34B171"" />
    </linearGradient>
    <linearGradient x1=""0.500000238"" y1=""-5.57899475E-05"" x2=""0.500000238"" y2=""1.00002813"" id=""PP_gradient_7"">
      <stop offset=""0"" stop-color=""#40D277"" />
      <stop offset=""0.704"" stop-color=""#38BC73"" />
      <stop offset=""1"" stop-color=""#34B171"" />
    </linearGradient>
  </defs>
  <g id=""svg"" transform=""scale(1.6)"">
    <path d=""M35 0L24 0C24 2.209 22.209 4 20 4C17.791 4 16 2.209 16 0L5 0C2.25 0 0 2.25 0 5L0 44C0 46.75 2.25 49 5 49L35 49C37.75 49 40 46.75 40 44L40 5C40 2.25 37.75 0 35 0L35 0Z"" transform=""translate(0 7)"" id=""Shape"" fill=""url(#PP_gradient_1)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PP_gradient_2)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PP_gradient_3)"" stroke=""none"" />
    <path d=""M11 0C14.866 0 18 3.134 18 7L22 7L22 13C22 14.657 20.657 16 19 16L3 16C1.343 16 0 14.657 0 13L0 7L4 7C4 3.134 7.134 0 11 0ZM8 7C8 8.657 9.343 10 11 10C12.657 10 14 8.657 14 7C14 5.343 12.657 4 11 4C9.343 4 8 5.343 8 7Z"" transform=""translate(9 0)"" id=""Shape"" fill=""url(#PP_gradient_4)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M9 4C10.105 4 11 3.105 11 2C11 0.895 10.105 0 9 0L2 0C0.895 0 0 0.895 0 2C0 3.105 0.895 4 2 4L9 4ZM9 18C10.105 18 11 17.105 11 16C11 14.895 10.105 14 9 14L2 14C0.895 14 0 14.895 0 16C0 17.105 0.895 18 2 18L9 18Z"" transform=""translate(8 24)"" id=""Shape"" fill=""url(#PP_gradient_5)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M12 1.9975C12 2.5075 11.8 3.0175 11.42 3.4075L7.83 6.9975L6.414 8.4135C5.633 9.1945 4.367 9.1945 3.586 8.4135L0.580002 5.4075C0.200001 5.0175 0 4.5075 0 3.9975C0 3.4775 0.200001 2.9675 0.580002 2.5775C1.36 1.8075 2.63 1.8075 3.41 2.5775L5 4.1675L8.59 0.577501C9.37 -0.192499 10.64 -0.192499 11.42 0.577501C11.8 0.966503 12 1.4765 12 1.9975L12 1.9975Z"" transform=""translate(21 21.00049)"" id=""Shape"" fill=""url(#PP_gradient_6)"" stroke=""none"" />
    <path d=""M12 1.9975C12 2.5075 11.8 3.0175 11.42 3.4075L7.83 6.9975L6.414 8.4135C5.633 9.1945 4.367 9.1945 3.586 8.4135L0.580002 5.4075C0.200001 5.0175 0 4.5075 0 3.9975C0 3.4775 0.200001 2.9675 0.580002 2.5775C1.36 1.8075 2.63 1.8075 3.41 2.5775L5 4.1675L8.59 0.577499C9.37 -0.192501 10.64 -0.192501 11.42 0.577499C11.8 0.967499 12 1.4775 12 1.9975L12 1.9975Z"" transform=""translate(21 35.0015)"" id=""Shape"" fill=""url(#PP_gradient_7)"" stroke=""none"" />
  </g>
  Pass Pass
</svg>
   </div>
   </div>
  </div>
  </div>
 </div>
 <div class=""col-md-3"">
  <div class=""card"">
  <div class=""card-body box-height-150"">
   <div class=""media justify-content-between"">
   <div class=""card-header"">
    <h6 class=""card-title"">Total Steps</h6>
    <h2 class=""font-size-28 font-weight-light mt-3"">{counts["childCount"]}</h2>
    <span class=""text-semibold text-success font-size-15"">
    <i class=""ti-arrow-up font-size-11""></i>
    <span>{ ((counts["passChild"] > 0) ? (Math.Round((Convert.ToDouble(counts["passChild"]) / (counts["passChild"] + counts["failChild"] + counts["exceptionsChild"])), 2) * 100) : 0)}%</span>
    </span>
   </div>
   <div class=""align-self-end"">
     <svg height=""100"" width=""80"" >
     <defs>
    <linearGradient x1=""0.5"" y1=""1.01871419"" x2=""0.5"" y2=""0.0187142789"" id=""PP_gradient_1"">
      <stop offset=""0"" stop-color=""#FF8B67"" />
      <stop offset=""0.847"" stop-color=""#FFA76A"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
      <stop offset=""1"" stop-color=""#FFAD6B"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""-0.0431025624"" x2=""0.5"" y2=""1.09997427"" id=""PP_gradient_2"">
      <stop offset=""0"" stop-color=""#FFCFA2"" />
      <stop offset=""1"" stop-color=""#FFD17C"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0"" x2=""0.5"" y2=""1"" id=""PP_gradient_3"">
      <stop offset=""0"" stop-color=""#FFF1E3"" />
      <stop offset=""1"" stop-color=""#FFF1D8"" />
    </linearGradient>
    <linearGradient x1=""0.5"" y1=""0.019125"" x2=""0.5"" y2=""1.3295"" id=""PP_gradient_4"">
      <stop offset=""0"" stop-color=""#ADADAD"" />
      <stop offset=""0.412"" stop-color=""#969696"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
    <linearGradient x1=""0.5000001"" y1=""1.08022237"" x2=""0.5000001"" y2=""-0.3283888"" id=""PP_gradient_5"">
      <stop offset=""0"" stop-color=""#F29265"" />
      <stop offset=""1"" stop-color=""#F9AE7F"" />
    </linearGradient>
    <linearGradient x1=""0.500000238"" y1=""-5.507469E-05"" x2=""0.500000238"" y2=""0.99991703"" id=""PP_gradient_6"">
      <stop offset=""0"" stop-color=""#40D277"" />
      <stop offset=""0.704"" stop-color=""#38BC73"" />
      <stop offset=""1"" stop-color=""#34B171"" />
    </linearGradient>
    <linearGradient x1=""0.500000238"" y1=""-5.57899475E-05"" x2=""0.500000238"" y2=""1.00002813"" id=""PP_gradient_7"">
      <stop offset=""0"" stop-color=""#40D277"" />
      <stop offset=""0.704"" stop-color=""#38BC73"" />
      <stop offset=""1"" stop-color=""#34B171"" />
    </linearGradient>
  </defs>
  <g id=""svg"" transform=""scale(1.6)"">
    <path d=""M35 0L24 0C24 2.209 22.209 4 20 4C17.791 4 16 2.209 16 0L5 0C2.25 0 0 2.25 0 5L0 44C0 46.75 2.25 49 5 49L35 49C37.75 49 40 46.75 40 44L40 5C40 2.25 37.75 0 35 0L35 0Z"" transform=""translate(0 7)"" id=""Shape"" fill=""url(#PP_gradient_1)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PP_gradient_2)"" stroke=""none"" />
    <path d=""M28 39L2 39C0.895001 39 0 38.105 0 37L0 2C0 0.895001 0.895001 0 2 0L28 0C29.105 0 30 0.895001 30 2L30 37C30 38.105 29.105 39 28 39L28 39Z"" transform=""translate(5 12)"" id=""Shape"" fill=""url(#PP_gradient_3)"" stroke=""none"" />
    <path d=""M11 0C14.866 0 18 3.134 18 7L22 7L22 13C22 14.657 20.657 16 19 16L3 16C1.343 16 0 14.657 0 13L0 7L4 7C4 3.134 7.134 0 11 0ZM8 7C8 8.657 9.343 10 11 10C12.657 10 14 8.657 14 7C14 5.343 12.657 4 11 4C9.343 4 8 5.343 8 7Z"" transform=""translate(9 0)"" id=""Shape"" fill=""url(#PP_gradient_4)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M9 4C10.105 4 11 3.105 11 2C11 0.895 10.105 0 9 0L2 0C0.895 0 0 0.895 0 2C0 3.105 0.895 4 2 4L9 4ZM9 18C10.105 18 11 17.105 11 16C11 14.895 10.105 14 9 14L2 14C0.895 14 0 14.895 0 16C0 17.105 0.895 18 2 18L9 18Z"" transform=""translate(8 24)"" id=""Shape"" fill=""url(#PP_gradient_5)"" fill-rule=""evenodd"" stroke=""none"" />
    <path d=""M12 1.9975C12 2.5075 11.8 3.0175 11.42 3.4075L7.83 6.9975L6.414 8.4135C5.633 9.1945 4.367 9.1945 3.586 8.4135L0.580002 5.4075C0.200001 5.0175 0 4.5075 0 3.9975C0 3.4775 0.200001 2.9675 0.580002 2.5775C1.36 1.8075 2.63 1.8075 3.41 2.5775L5 4.1675L8.59 0.577501C9.37 -0.192499 10.64 -0.192499 11.42 0.577501C11.8 0.966503 12 1.4765 12 1.9975L12 1.9975Z"" transform=""translate(21 21.00049)"" id=""Shape"" fill=""url(#PP_gradient_6)"" stroke=""none"" />
    <path d=""M12 1.9975C12 2.5075 11.8 3.0175 11.42 3.4075L7.83 6.9975L6.414 8.4135C5.633 9.1945 4.367 9.1945 3.586 8.4135L0.580002 5.4075C0.200001 5.0175 0 4.5075 0 3.9975C0 3.4775 0.200001 2.9675 0.580002 2.5775C1.36 1.8075 2.63 1.8075 3.41 2.5775L5 4.1675L8.59 0.577499C9.37 -0.192501 10.64 -0.192501 11.42 0.577499C11.8 0.967499 12 1.4775 12 1.9975L12 1.9975Z"" transform=""translate(21 35.0015)"" id=""Shape"" fill=""url(#PP_gradient_7)"" stroke=""none"" />
  </g>
  Pass Pass
</svg>
   </div>
   </div>
  </div>
  </div>
 </div>
 <div class=""col-md-3"">
  <div class=""card"">
  <div class=""card-body box-height-150"">
   <div class=""media justify-content-between"">
   <div class=""card-header"">
    <h6 class=""card-title"">Start Time</h6>
    <h4 class=""font-weight-light mt-4"">{startDate + " " + startTime}</h4>
    <span class=""text-semibold text-success font-size-15"">
   </div>
   <div class=""align-self-end"">
   <svg height=""100"" width=""80"" style=""padding-top:10px"">
  <defs>
    <linearGradient x1=""0.5437498"" y1=""-0.06825018"" x2=""0.469249964"" y2=""0.8998749"" id=""ST_gradient_1"">
      <stop offset=""0"" stop-color=""#A4A4A4"" />
      <stop offset=""0.619"" stop-color=""#808080"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
  </defs>
  <g id=""Start-Time"" transform=""scale(1.6)"">
    <path d=""M9.38089 5.66681C9.16558 5.88213 8.9209 6.06809 8.66643 6.22468L2.45153 10.0026C1.80558 10.4038 0.924725 10.3451 0.406001 9.78724C-0.00506267 9.32723 -0.0931479 8.72043 0.09281 8.2017L3.05834 0C4.77111 2.28043 6.91451 4.20851 9.38089 5.66681L9.38089 5.66681Z"" transform=""translate(2.686768 38.57237)"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
    <path d=""M8.74 9.88511C8.21149 10.2081 7.5949 10.1689 7.1251 9.88511L0 5.54936C2.44681 4.13021 4.58043 2.23149 6.29319 0C6.54766 0.332766 6.75319 0.704682 6.89021 1.09617L9.3566 7.92766C9.62085 8.64213 9.39574 9.49362 8.74 9.88511L8.74 9.88511Z"" transform=""translate(33.82468 38.74858)"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
    <path d=""M19.6772 6.70124L5.06677 18.5418L1.60307 14.2883C-0.829057 11.3893 -0.45127 7.06826 2.44771 4.63613L6.56128 1.60307C9.46026 -0.829057 13.7813 -0.45127 16.2135 2.44771L19.6772 6.70124L19.6772 6.70124Z"" transform=""translate(0.1499939 0)"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
    <path d=""M0 6.70124L14.6104 18.5418L18.0741 14.2883C20.5062 11.3893 20.1284 7.06826 17.2295 4.63613L13.1159 1.60307C10.2169 -0.829057 5.89583 -0.45127 3.46371 2.44771L0 6.70124L0 6.70124Z"" transform=""translate(26.17105 0)"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
    <path d=""M0 22.5106C0 10.0784 10.2975 0 23 0C35.7025 0 46 10.0784 46 22.5106C46 34.9429 35.7025 45.0213 23 45.0213C10.2975 45.0213 0 34.9429 0 22.5106Z"" transform=""translate(0 3.171967)"" id=""Ellipse"" fill=""#3CC675"" stroke=""none"" />
    <path d=""M35.234 17.617C35.234 18.2826 35.1949 18.9285 35.1264 19.5745C34.2064 27.9328 27.4336 34.5294 18.997 35.1753C18.997 35.1753 18.9872 35.1753 18.9774 35.1753C18.5272 35.2145 18.077 35.234 17.617 35.234C7.88851 35.234 0 27.3455 0 17.617C0 16.9515 0.0391489 16.3055 0.107659 15.6596C0.890638 8.62255 5.80383 2.8383 12.3809 0.792766C14.0349 0.274042 15.7966 0 17.617 0C27.3455 0 35.234 7.88851 35.234 17.617L35.234 17.617Z"" transform=""translate(5.382965 8.065582)"" id=""Shape"" fill=""#FFFFFF"" stroke=""none"" />
    <path d=""M0.978724 11.7447L0.978724 0"" transform=""translate(22.02127 13.93793)"" id=""Line"" fill=""none"" stroke=""none"" />
    <path d=""M0 0L5.87234 5.87234"" transform=""translate(23 25.6826)"" id=""Line"" fill=""none"" stroke=""none"" />
    <path d=""M0 3.91489C0 1.75276 1.75276 0 3.91489 0C6.07703 0 7.82979 1.75276 7.82979 3.91489C7.82979 6.07703 6.07703 7.82979 3.91489 7.82979C1.75276 7.82979 0 6.07703 0 3.91489Z"" transform=""translate(19.08511 21.76772)"" id=""Circle"" fill=""url(#ST_gradient_1)"" stroke=""none"" />
  </g>
  Start Time
</svg>
   </div>
   </div>
  </div>
  </div>
 </div>
 <div class=""col-md-3"">
  <div class=""card"">
  <div class=""card-body box-height-150"">
   <div class=""media justify-content-between"">
   <div class=""card-header"">
    <h6 class=""card-title"">End Time</h6>
    <h4 class=""font-weight-light mt-4"">{endDate + " " + endTime}</h4>
    <span class=""text-semibold font-size-15"">
   </div>
   <div class=""align-self-end"">
    <svg height=""100"" width=""80"" style=""padding-top:10px"">
 <defs>
    <linearGradient x1=""0.5437498"" y1=""-0.06825018"" x2=""0.469249964"" y2=""0.8998749"" id=""ET_gradient_1"">
      <stop offset=""0"" stop-color=""#A4A4A4"" />
      <stop offset=""0.619"" stop-color=""#808080"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
      <stop offset=""1"" stop-color=""#6F6F6F"" />
    </linearGradient>
  </defs>
  <g id=""End-Time"" transform=""scale(1.6)"">
    <path d=""M9.38089 5.66681C9.16558 5.88213 8.9209 6.06809 8.66643 6.22468L2.45153 10.0026C1.80558 10.4038 0.924725 10.3451 0.406001 9.78724C-0.00506267 9.32723 -0.0931479 8.72043 0.09281 8.2017L3.05834 0C4.77111 2.28043 6.91451 4.20851 9.38089 5.66681L9.38089 5.66681Z"" transform=""translate(2.686768 38.57234)"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
    <path d=""M8.74 9.88511C8.21149 10.2081 7.5949 10.1689 7.1251 9.88511L0 5.54936C2.44681 4.13021 4.58043 2.23149 6.29319 0C6.54766 0.332766 6.75319 0.704682 6.89021 1.09617L9.3566 7.92766C9.62085 8.64213 9.39574 9.49362 8.74 9.88511L8.74 9.88511Z"" transform=""translate(33.82471 38.74855)"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
    <path d=""M19.6772 6.70124L5.06677 18.5418L1.60307 14.2883C-0.829057 11.3893 -0.45127 7.06826 2.44771 4.63613L6.56128 1.60307C9.46026 -0.829057 13.7813 -0.45127 16.2135 2.44771L19.6772 6.70124L19.6772 6.70124Z"" transform=""translate(0.1500244 0)"" id=""Shape"" fill=""#FF6354"" stroke=""none"" />
    <path d=""M0 6.70124L14.6104 18.5418L18.0741 14.2883C20.5062 11.3893 20.1284 7.06826 17.2295 4.63613L13.1159 1.60307C10.2169 -0.829057 5.89583 -0.45127 3.46371 2.44771L0 6.70124L0 6.70124Z"" transform=""translate(26.17102 0)"" id=""Shape"" fill=""#FE645D"" stroke=""none"" />
    <path d=""M0 22.5106C0 10.0784 10.2975 0 23 0C35.7025 0 46 10.0784 46 22.5106C46 34.9429 35.7025 45.0213 23 45.0213C10.2975 45.0213 0 34.9429 0 22.5106Z"" transform=""translate(0 3.171967)"" id=""Ellipse"" fill=""#FE645B"" stroke=""none"" />
    <path d=""M35.234 17.617C35.234 18.2826 35.1949 18.9285 35.1264 19.5745C34.2064 27.9328 27.4336 34.5294 18.997 35.1753C18.997 35.1753 18.9872 35.1753 18.9774 35.1753C18.5272 35.2145 18.077 35.234 17.617 35.234C7.88851 35.234 0 27.3455 0 17.617C0 16.9515 0.0391489 16.3055 0.107659 15.6596C0.890638 8.62255 5.80383 2.8383 12.3809 0.792766C14.0349 0.274042 15.7966 0 17.617 0C27.3455 0 35.234 7.88851 35.234 17.617L35.234 17.617Z"" transform=""translate(5.382935 8.065582)"" id=""Shape"" fill=""#FFFFFF"" stroke=""none"" />
    <path d=""M0.978724 11.7447L0.978724 0"" transform=""translate(22.02124 13.93793)"" id=""Line"" fill=""none"" stroke=""none"" />
    <path d=""M0 0L5.87234 5.87234"" transform=""translate(23 25.68259)"" id=""Line"" fill=""none"" stroke=""none"" />
    <path d=""M0 3.91489C0 1.75276 1.75276 0 3.91489 0C6.07703 0 7.82979 1.75276 7.82979 3.91489C7.82979 6.07703 6.07703 7.82979 3.91489 7.82979C1.75276 7.82979 0 6.07703 0 3.91489Z"" transform=""translate(19.08508 21.76772)"" id=""Circle"" fill=""url(#ET_gradient_1)"" stroke=""none"" />
  </g>
  End Time
</svg>
   </div>
   </div>
  </div>
  </div>
 </div>
 </div>
 
 <div class=""row"">
 <div class=""col-md-6"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Prioritywise Report</h6>
  </div>
  <div class=""table-overflow"">
   <table class=""table table-sm"">
   <thead>
    <tr class=""bg-gray"">
    <th>Priority</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
    {getReport(priorityReportData)}
   </tbody>
   </table>
  </div>
  </div>
 </div>
 <div class=""col-md-6"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Tagwise Report</h6>
  </div>
  <div class=""table-overflow"">
   <table class=""table table-sm"">
   <thead>
    <tr class=""bg-gray"">
    <th>Name</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
     {getReport(tagReportData)}
   </tbody>
   </table>
  </div>
  </div>
 </div>
 <div class=""col-md-6"">
  <div class=""card"">
  <div class=""card-header"">
   <h6 class=""card-title"">Suitewise Report</h6>
  </div>
  <div class=""table-overflow"">
   <table class=""table table-sm"">
   <thead>
    <tr class=""bg-gray"">
    <th>Suite</th>
    <th>Total</th>
    <th>Passed</th>
    <th>Failed</th>
    <th>Passed %</th>
    </tr>
   </thead>
   <tbody>
    {getReport(suiteReportData)}
   </tbody>
   </table>
  </div>
  </div>
 </div>
 </div>
</div>
<script>
 var statusGroup = {openingBrace}
 parentCount: {counts["parentCount"]},
 passParent: {counts["passParent"]},
 failParent: {counts["failParent"]},
 fatalParent: 0,
 errorParent: 0,
 warningParent: 0,
 skipParent: 0,
 exceptionsParent: 0,

 childCount: {counts["childCount"]},
 passChild: {counts["passChild"]},
 failChild: {counts["failChild"]},
 warningChild: {counts["warningChild"]},
 skipChild: {counts["skipChild"]},
 infoChild: {counts["infoChild"]},
 exceptionsChild: {counts["exceptionsChild"]},
 fatalChild: 0,
 errorChild: 0,
 debugChild: 0,

 eventsCount: {(counts["parentCount"] + counts["childCount"])},
 passEvents: {counts["passEvents"]},
 failEvents: {counts["failEvents"]},
 warningEvents: {counts["warningChild"]},
 skipEvents: {counts["skipChild"]},
 infoEvents: {counts["infoChild"]},
 exceptionsEvents: {counts["exceptionsChild"]},
 fatalEvents: 0,
 errorEvents: 0,
 debugEvents: 0
 {closingBrace};
</script>
        </div>
      </div>
    </div>
  </div>
	    <script>
{Script.getScript()}
</script>
</body>
</html>
            ";

            File.WriteAllText(reportPath, reportTemplate);
        }
    }
}
