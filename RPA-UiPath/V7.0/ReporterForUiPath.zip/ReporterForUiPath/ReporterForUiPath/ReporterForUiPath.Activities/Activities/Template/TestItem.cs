﻿using System;
using System.Collections.Generic;

namespace Self.UiPathReporter.Activities.Activities.Template
{
    class TestItem
    {
        public String testId;
        public String testName;
        public String startDate;
        public String startTime;
        public String endDate;
        public String endTime;
        public String status = "Pass";
        public String description = "Default Test Description";
        public String tagName = "";
        public String suiteName = ReportTemplate.currentSuite;
        public String priority = "Low";
        public List<StepItem> stepItems = new List<StepItem>();

        //New
        private string tagTemplate;
        private string priorityColor;
        private string _status;
        private string testTemplate;
        private string testIcon;
        private string steps;

        public TestItem(String _testName, String _description, String _tagName, String _priority)
        {
            testId = suiteName + ReportTemplate.testCounter;
            ReportTemplate.currentTestId = testId;
            testName = _testName;
            description = _description;
            tagName = _tagName;
            priority = _priority;
            startDate = Utility.getCurrentDate("/");
            startTime = Utility.getCurrentTime(":");
            endDate = startDate;
            endTime = startTime;
            ReportTemplate.testCounter++;
            ReportTemplate.suiteReportData[suiteName][0]++; // Default Increment Pass Counter
            ReportTemplate.priorityReportData[priority][0]++;
            if (tagName.Length >= 1)
            {
                ReportTemplate.tagReportData[tagName][0]++;
            }
        }

        public String getAllSteps()
        {
            steps = "";
            foreach (StepItem step in stepItems)
            {
                steps = steps + step.getStep() + "\n";
            }
            return steps;
        }

        public String getTest()
        {
             tagTemplate = "";
            priorityColor="";
            if (tagName.Length > 0) tagTemplate = $"&nbsp;&nbsp;&nbsp;Tag : <b>{tagName}</b>";

             testIcon = @"
			<svg height=""20"" width=""28"">
			<g id=""check-green"" transform=""scale(0.4)"">
			<path d=""M45.9637 1.03575L19.4818 27.5178L6.03575 14.0357C4.65475 12.6547 2.41675 12.6547 1.03575 14.0357L1.03575 14.0357C-0.34525 15.4167 -0.34525 17.6547 1.03575 19.0357L16.8557 34.8907C18.3067 36.3418 20.6587 36.3418 22.1097 34.8907L50.9647 6.03575C52.3457 4.65475 52.3457 2.41675 50.9647 1.03575L50.9647 1.03575C49.5837 -0.34525 47.3447 -0.34525 45.9637 1.03575L45.9637 1.03575Z"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
			</g>
			Pass
			</svg>
			";
            if (!status.Equals("Pass"))
            {
                testIcon = @"
			<svg height=""25"" width=""28"">
			<g id=""check-green"" transform=""scale(0.4)"">
			<path d=""M40.937 1.05725L40.94 1.06025C42.353 2.47225 42.354 4.76225 40.941 6.17425L6.171 40.9382C4.759 42.3503 2.47 42.3503 1.059 40.9382L1.059 40.9382C-0.353 39.5263 -0.353 37.2373 1.059 35.8252L35.825 1.05925C37.237 -0.35275 39.525 -0.35275 40.937 1.05725L40.937 1.05725Z"" transform=""translate(0.0002441406 0.003753662)"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
			<path d=""M40.9372 40.947L40.9372 40.947C39.5252 42.359 37.2362 42.359 35.8242 40.947L1.05825 6.171C-0.35275 4.759 -0.35275 2.47 1.05825 1.059L1.05825 1.059C2.47025 -0.353 4.75925 -0.353 6.17125 1.059L40.9372 35.835C42.3493 37.247 42.3493 39.536 40.9372 40.947L40.9372 40.947Z"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
			</g>
			Fail
			</svg>
			";
            }
            if (priority.Equals("Low")) priorityColor = "green";
            else if (priority.Equals("Medium")) priorityColor = "orange";
            else if (priority.Equals("High")) priorityColor = "purple";
            else if (priority.Equals("Critical")) priorityColor = "red";
            else priorityColor = "orange";
             _status = status.ToLower();
             testTemplate = $@"
  <li class=""test-item"" status=""{_status}"" test-id=""{testId}""
   author=""{suiteName}""
   tag=""{tagName}""
   priority=""{priority}"">
   <div class=""status-avatar"">
	{testIcon}
   </div>
   <div class=""open-test"">
   <div class=""test-detail"">
    <p class=""name"">{testName}</p>
    <p class=""duration text-sm"">Steps : <b>{stepItems.Count}</b>&nbsp;&nbsp;&nbsp;Suite : <b>{suiteName}</b>{tagTemplate}</p>
    <p class=""datetime"">{startTime}</br><b style=""color:{priorityColor}"">{priority}</b></p>
   </div>
   </div>
   <div class=""test-contents d-none"">
   <div class=""detail-head"">
    <div class=""p-v-10 d-inline-block"">
    <div class=""info"">
     <h5 class=""test-status text-{_status}"">{testName}</h5>
     <span class='badge badge-success'>Start : {startDate + " " + startTime}</span>
     <span class='badge badge-danger'>End : {endDate + " " + endTime}</span>
     <span class='badge badge-default'>Time Taken : {Utility.calculateDifference(startTime, endTime)}</span>
    </div>
    <div class=""m-t-10 m-l-5"">
    {description}
    </div>
    </div>
   </div>
<div class=""detail-body mt-4"">
<table class=""table table-sm"">
 <thead><tr>
 <th class=""status-col"">Status</th>
 <th class=""timestamp-col"">Timestamp</th>
 <th class=""details-col"">Details</th>
 </tr></thead>
 <tbody>
  {getAllSteps()}
 </tbody>
</table>
</div>
</div>
</li>
";
            return testTemplate;
        }

    }
}
