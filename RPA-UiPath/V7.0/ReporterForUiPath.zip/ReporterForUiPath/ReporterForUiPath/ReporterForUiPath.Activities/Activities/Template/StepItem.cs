﻿using System;

namespace Self.UiPathReporter.Activities.Activities.Template
{
    class StepItem
    {
        public String stepName;
        public String stepStatus;
        public String logTime;
        public String stepDescription;
        public String stepException = "";
        public String expectedResult;
        public String actualResult;
        public bool takeScreenshot;
        public String screenshotName;

        private TestItem currectStepTest;
        private string imgName;
        private string screenshotSavePath;
        private string exceptionBlock;
        private string imageTemplate;
        private string expectedTemplate;
        private string actualTemplate;
        private string statusIcon;
        private string stepTemplate;

        public StepItem(String _stepName, String _stepStatus, String _stepDescription, bool _takeScreenshot)
        {
            stepName = _stepName;
            stepStatus = _stepStatus;
            stepDescription = _stepDescription;
            takeScreenshot = _takeScreenshot;
            logTime = Utility.getCurrentTime(":");
            currectStepTest = ReportTemplate.testItems[ReportTemplate.currentTestId];

            if ("Fail,Exception,Skip".Contains(stepStatus) && currectStepTest.status.Equals("Pass"))
            {
                currectStepTest.status = "Fail";
                ReportTemplate.counts["passParent"]--;
                ReportTemplate.counts["failParent"]++;
                ReportTemplate.suiteReportData[currectStepTest.suiteName][0]--;
                ReportTemplate.suiteReportData[currectStepTest.suiteName][1]++;
                ReportTemplate.priorityReportData[currectStepTest.priority][0]--;
                ReportTemplate.priorityReportData[currectStepTest.priority][1]++;
                if (currectStepTest.tagName.Length >= 1)
                {
                    ReportTemplate.tagReportData[currectStepTest.tagName][0]--;
                    ReportTemplate.tagReportData[currectStepTest.tagName][1]++;
                }
            }
            if (takeScreenshot)
            {
                 imgName = ReportTemplate.currentTestId + "_" + stepName + "_" + Utility.getCurrentTimeForScreenshot() + ".jpg";
                 screenshotSavePath = ReportTemplate.screenshotLocation + "\\" + imgName;
                Utility.takeScreenShot(screenshotSavePath);
                screenshotName = ".\\screenshots\\" + imgName;
            }
            updateCount();
        }

        public void updateCount()
        {
            ReportTemplate.counts["childCount"]++;
            if (stepStatus.Equals("Pass")) ReportTemplate.counts["passChild"]++;
            else if (stepStatus.Equals("Fail")) ReportTemplate.counts["failChild"]++;
            else if (stepStatus.Equals("Warning")) ReportTemplate.counts["warningChild"]++;
            else if (stepStatus.Equals("Skip")) ReportTemplate.counts["skipChild"]++;
            else if (stepStatus.Equals("Info")) ReportTemplate.counts["infoChild"]++;
            else if (stepStatus.Equals("Exception")) ReportTemplate.counts["exceptionsChild"]++;

            ReportTemplate.counts["passEvents"] = ReportTemplate.counts["passParent"] + ReportTemplate.counts["passChild"];
            ReportTemplate.counts["failEvents"] = ReportTemplate.counts["failParent"] + ReportTemplate.counts["failChild"];
            ReportTemplate.counts["otherEvents"] = (ReportTemplate.counts["parentCount"] + ReportTemplate.counts["childCount"]) - (ReportTemplate.counts["passEvents"] + ReportTemplate.counts["failEvents"]);
        }

        public String getStep()
        {
             exceptionBlock = "";
             imageTemplate = $@"{stepName}:&nbsp;";
             expectedTemplate = "";
             actualTemplate = "";
             statusIcon = "";
            if (stepException.Length >= 1)
            {
                exceptionBlock = $@"</br></br><textarea disabled class=""code-block"">{stepException}</textarea>";
            }
            if (takeScreenshot)
            {
                imageTemplate = $@"<a href = '{screenshotName}' data-featherlight='image'><span class='label grey badge white-text text-white'>{stepName}-img</span></a>&nbsp;&nbsp;";
            }
            if (expectedResult.Length >= 1)
            {
                expectedTemplate = $@"</br>Expected  : {expectedResult}";
            }
            if (actualResult.Length >= 1)
            {
                actualTemplate = $@"</br>Actual&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {actualResult}";
            }
            if (stepStatus.Equals("Pass"))
            {
                statusIcon = @"
			<svg height=""13"" width=""16"">
			<g id=""check-green"" transform=""scale(0.3)"">
			<path d=""M45.9637 1.03575L19.4818 27.5178L6.03575 14.0357C4.65475 12.6547 2.41675 12.6547 1.03575 14.0357L1.03575 14.0357C-0.34525 15.4167 -0.34525 17.6547 1.03575 19.0357L16.8557 34.8907C18.3067 36.3418 20.6587 36.3418 22.1097 34.8907L50.9647 6.03575C52.3457 4.65475 52.3457 2.41675 50.9647 1.03575L50.9647 1.03575C49.5837 -0.34525 47.3447 -0.34525 45.9637 1.03575L45.9637 1.03575Z"" id=""Shape"" fill=""#3CC675"" stroke=""none"" />
			</g>
			Pass
			</svg>	
			";
            }
            else if (stepStatus.Equals("Fail"))
            {
                statusIcon = @"
			<svg height=""13"" width=""13"">
			<g id=""red-cross"" transform=""scale(0.3)"">
			<path d=""M40.937 1.05725L40.94 1.06025C42.353 2.47225 42.354 4.76225 40.941 6.17425L6.171 40.9382C4.759 42.3503 2.47 42.3503 1.059 40.9382L1.059 40.9382C-0.353 39.5263 -0.353 37.2373 1.059 35.8252L35.825 1.05925C37.237 -0.35275 39.525 -0.35275 40.937 1.05725L40.937 1.05725Z"" transform=""translate(0.0002441406 0.003753662)"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
			<path d=""M40.9372 40.947L40.9372 40.947C39.5252 42.359 37.2362 42.359 35.8242 40.947L1.05825 6.171C-0.35275 4.759 -0.35275 2.47 1.05825 1.059L1.05825 1.059C2.47025 -0.353 4.75925 -0.353 6.17125 1.059L40.9372 35.835C42.3493 37.247 42.3493 39.536 40.9372 40.947L40.9372 40.947Z"" id=""Shape"" fill=""#FE645B"" stroke=""none"" />
			</g>
			Fail
			</svg>
			";
            }
            else if (stepStatus.Equals("Skip"))
            {
                statusIcon = @"
			<svg height=""13"" width=""17"">
			<g id=""skip"" transform=""scale(0.3),matrix(-0.9993908 -0.03489945 0.03489945 -0.9993908 51.73322 38.78604)"">
			<path d=""M51.747 33.248C51.357 29.407 50.292 25.503 48.344 21.86C46.406 18.227 43.539 14.873 39.871 12.385C36.212 9.89902 31.793 8.35502 27.333 7.93802L19.149 7.03202L19.149 2.78202C19.149 0.386017 16.329 -0.884983 14.543 0.707017L0.756 13.006C-0.252 13.906 -0.252 15.486 0.756 16.386L14.542 28.685C16.326 30.277 19.148 29.005 19.148 26.61L19.148 22.359L27.134 21.47C29.565 21.123 32.024 21.353 34.389 22.237C36.743 23.13 38.982 24.705 40.835 26.843C42.691 28.978 44.15 31.644 45.119 34.58L45.148 34.669C45.637 36.152 47.101 37.15 48.714 36.984C50.579 36.791 51.937 35.119 51.747 33.248L51.747 33.248Z"" transform=""translate(-6.103516E-05 0)"" id=""Shape"" fill=""#3199EA"" stroke=""none"" />
			</g>
			Skip
			</svg>
			";
            }
            else if (stepStatus.Equals("Warning"))
            {
                statusIcon = @"
			<svg height=""13"" width=""15"">
			<g id=""Priority"" transform=""scale(0.3)"">
			<path d=""M0.515127 38.199L21.4821 1.734C22.0991 0.661 23.2421 0 24.4791 0L24.4791 0C25.7161 0 26.8591 0.661 27.4761 1.734L48.4431 38.199C49.0901 39.324 49.1301 40.698 48.5501 41.859L48.5491 41.861C47.8931 43.172 46.5531 44 45.0871 44L3.87113 44C2.40513 44 1.06513 43.172 0.410127 41.861L0.409127 41.859C-0.171873 40.698 -0.131873 39.324 0.515127 38.199L0.515127 38.199Z"" id=""Shape"" fill=""#FF9F58"" stroke=""none"" />
			<path d=""M0 3C0 1.343 1.343 0 3 0C4.657 0 6 1.343 6 3L5.133 16.004C5.058 17.127 4.125 18 3 18C1.875 18 0.941999 17.127 0.867001 16.004L0 3ZM3 25C4.105 25 5 24.105 5 23C5 21.895 4.105 21 3 21C1.895 21 1 21.895 1 23C1 24.105 1.895 25 3 25Z"" transform=""translate(21.47913 14)"" id=""Shape"" fill=""#EEEEEE"" fill-rule=""evenodd"" stroke=""none"" />
			</g>
			Warning
			</svg>
			";
            }
            else if (stepStatus.Equals("Info"))
            {
                statusIcon = @"
			<svg height=""16"" width=""12"" style=""padding-left:5px"">
			<g id=""info"" transform=""scale(0.25)"">
			<path d=""M12 14C15.866 14 19 10.866 19 7C19 3.134 15.866 0 12 0C8.134 0 5 3.134 5 7C5 10.866 8.134 14 12 14ZM18 42L23 42C24.657 42 26 43.343 26 45L26 49C26 50.657 24.657 52 23 52L3 52C1.343 52 0 50.657 0 49L0 45C0 43.343 1.343 42 3 42L8 42L8 29L3 29C1.343 29 0 27.657 0 26L0 21C0 19.343 1.343 18 3 18L15 18C16.657 18 18 19.343 18 21L18 42Z"" id=""Shape"" fill=""#3199EA"" fill-rule=""evenodd"" stroke=""none"" />
			</g>
			Info
			</svg>
			";
            }
            else if (stepStatus.Equals("Exception"))
            {
                statusIcon = @"
			<svg height=""17"" width=""10""  style=""padding-left:5px"">
			<g id=""exception"" transform=""scale(0.4)"">
			<path d=""M5.125 0C7.95546 0 10.25 2.29453 10.25 5.125C10.25 5.16014 10.2398 5.19382 10.2398 5.22896L10.25 5.22896L8.4665 26.1595C8.31568 27.9283 6.86457 29.2857 5.125 29.2857C3.38543 29.2857 1.93432 27.9283 1.7835 26.1595L0 5.22896L0.01025 5.22896C0.01025 5.19382 0 5.16014 0 5.125C0 2.29453 2.29454 0 5.125 0ZM5.125 41C7.14718 41 8.78571 39.3615 8.78571 37.3393C8.78571 35.3171 7.14718 33.6786 5.125 33.6786C3.10282 33.6786 1.46429 35.3171 1.46429 37.3393C1.46429 39.3615 3.10282 41 5.125 41Z"" id=""Shape"" fill=""#FF9757"" fill-rule=""evenodd"" stroke=""none"" />
			</g>
			Exception
			</svg>
			";
            }
             stepTemplate = $@"
 <tr class=""event-row"">
  <td>
  {statusIcon}
  </td>
  <td>{logTime}</td>
  <td>
   {imageTemplate}
   {stepDescription}
   {expectedTemplate}
   {actualTemplate}
   {exceptionBlock}
  </td>
  </tr>
            ";
            return stepTemplate;
        }
    }
}
