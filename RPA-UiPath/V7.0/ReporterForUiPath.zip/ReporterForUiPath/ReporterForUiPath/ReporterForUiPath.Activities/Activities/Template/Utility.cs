﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Self.UiPathReporter.Activities.Activities.Template
{
    class Utility
    {
        public static Dictionary<String, String> statusClass = new Dictionary<String, String>();

        static Utility()
        {
            statusClass.Add("Pass", "fa fa-check text-pass");
            statusClass.Add("Fail", "fa fa-times text-fail");
            statusClass.Add("Warning", "fa fa-warning text-warning");
            statusClass.Add("Skip", "fa fa-long-arrow-right text-skip");
            statusClass.Add("Info", "fa fa-info text-info");
            statusClass.Add("Exception", "fa fa-exclamation text-error");
        }

        public static String getCurrentDate(String deliminator)
        {
            return DateTime.Now.ToString("dd" + deliminator + "MM" + deliminator + "yyyy");
        }
        public static String getCurrentTime(String deliminator)
        {
            return DateTime.Now.ToString("hh" + deliminator + "mm" + deliminator + "ss tt");
        }
        public static String getCurrentTimeForScreenshot()
        {
            return DateTime.Now.ToString("hh_mm_ss_ffffff");
        }

        public static String calculateDifference(String startTime, String endTime)
        {
            TimeSpan duration = DateTime.Parse(endTime).Subtract(DateTime.Parse(startTime));
            return duration.ToString();
        }

        public static void takeScreenShot(String imageName)
        {
            Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics g = Graphics.FromImage(bmp);
            g.CopyFromScreen(0, 0, 0, 0, Screen.PrimaryScreen.Bounds.Size);
            bmp.Save(imageName);  // saves the image
        }

    }
}
