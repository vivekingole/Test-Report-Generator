using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.CreateReport_DisplayName))]
    [LocalizedDescription(nameof(Resources.CreateReport_Description))]
    public class CreateReport : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateReport_ReportName_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateReport_ReportName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> ReportName { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateReport_ReportLocation_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateReport_ReportLocation_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> ReportLocation { get; set; }

        [LocalizedDisplayName("isReportCreated")]
        [LocalizedDescription("Is New Report Created")]
        [LocalizedCategory("Output")]
        public OutArgument<Boolean> isCreated { get; set; }

        #endregion


        #region Constructors

        public CreateReport()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (ReportName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(ReportName)));
            if (ReportLocation == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(ReportLocation)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var reportName = ReportName.Get(context);
            var reportLocation = ReportLocation.Get(context);

            ///////////////////////////
            if (ReportTemplate.reportCreated)
            {
                ReportTemplate.suiteCreated = false;
                ReportTemplate.testCreated = false;
                ReportTemplate.testCounter = 1;
                ReportTemplate.currentSuite = "DefaultSuite";
                ReportTemplate.suites = new List<String>();
                ReportTemplate.tags = new List<String>();
                ReportTemplate.testItems = new Dictionary<String, TestItem>();
                ReportTemplate.counts = new Dictionary<String, Int32>();
                ReportTemplate.priorityReportData = new Dictionary<String, List<Int32>>();
                ReportTemplate.tagReportData = new Dictionary<String, List<Int32>>();
                ReportTemplate.suiteReportData = new Dictionary<String, List<Int32>>();
            }
            new ReportTemplate(reportName, reportLocation);
            ReportTemplate.updateReport();
            ReportTemplate.reportCreated = true;
            ///////////////////////////

            // Outputs
            return (ctx) =>
            {
                try
                {
                    if (File.Exists(ReportTemplate.reportPath))
                    {
                        isCreated.Set(ctx, true);
                    }
                    else
                    {
                        isCreated.Set(ctx, false);
                    }
                }catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                    isCreated.Set(ctx, false);
                }
            };
        }

        #endregion
    }
}

