using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using Self.UiPathReporter.Activities.Activities.Template.Recorder;
using System;
using System.Activities;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.StartRecording_DisplayName))]
    [LocalizedDescription(nameof(Resources.StartRecording_Description))]
    public class StartRecording : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartRecording_RecordingName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartRecording_RecordingName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> RecordingName { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartRecording_Location_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartRecording_Location_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> Location { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartRecording_SaveInCurrentReport_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartRecording_SaveInCurrentReport_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public bool SaveInCurrentReport { get; set; } = true;

        [LocalizedDisplayName("isRecordingStarted")]
        [LocalizedDescription("Is Recording Started")]
        [LocalizedCategory("Output")]
        public OutArgument<Boolean> isStarted { get; set; }

        #endregion


        #region Constructors

        public StartRecording()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (RecordingName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(RecordingName)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var recordingName = RecordingName.Get(context);
            var location = Location.Get(context);

            ///////////////////////////
            if (SaveInCurrentReport && ReportTemplate.reportCreated)
            {
                recordingName = ReportTemplate.recordingsLocation + "\\" + recordingName + "_" + Utility.getCurrentTimeForScreenshot() + ".avi";
            }
            else if (SaveInCurrentReport && !ReportTemplate.reportCreated)
            {
                String recordingLocation = ".\\Recordings\\";
                Directory.CreateDirectory(recordingLocation);
                recordingName = recordingLocation + recordingName + "_" + Utility.getCurrentDate("_") + "_" + Utility.getCurrentTimeForScreenshot() + ".avi";
            }
            else
            {
                if (location == null || location.Length == 0)
                {
                    String recordingLocation = ".\\Recordings\\";
                    Directory.CreateDirectory(recordingLocation);
                    recordingName = recordingLocation + recordingName + "_" + Utility.getCurrentDate("_") + "_" + Utility.getCurrentTimeForScreenshot() + ".avi";
                }
                else
                {
                    recordingName = location + "\\" + recordingName + "_" + Utility.getCurrentDate("_") + "_" + Utility.getCurrentTimeForScreenshot() + ".avi";
                }
            }

            if (recordingName.Length >= 5 && !Recorder.isRecording)
            {
                Recorder.recorder = new Recorder(new RecorderParams(recordingName, 10, SharpAvi.KnownFourCCs.Codecs.MotionJpeg, 70));
                Recorder.isRecording = true;
            }
            ///////////////////////////

            // Outputs
            return (ctx) =>
            {
                try
                {
                    if (File.Exists(RecorderParams.FileName))
                    {
                        isStarted.Set(ctx, true);
                    }
                    else
                    {
                        isStarted.Set(ctx, false);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    isStarted.Set(ctx, false);
                }
            };
        }

        #endregion
    }
}

