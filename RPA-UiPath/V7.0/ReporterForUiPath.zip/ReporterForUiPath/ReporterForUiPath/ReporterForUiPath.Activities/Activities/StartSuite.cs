using ReporterForUiPath.Activities.Properties;
using Self.UiPathReporter.Activities.Activities.Template;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace ReporterForUiPath.Activities
{
    [LocalizedDisplayName(nameof(Resources.StartSuite_DisplayName))]
    [LocalizedDescription(nameof(Resources.StartSuite_Description))]
    public class StartSuite : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartSuite_SuiteName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartSuite_SuiteName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> SuiteName { get; set; }

        [LocalizedDisplayName("Suites")]
        [LocalizedDescription("List of all Suites in current Report")]
        [LocalizedCategory("Output")]
        public OutArgument<List<String>> suiteList { get; set; }

        #endregion


        #region Constructors

        public StartSuite()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (SuiteName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(SuiteName)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var suiteName = SuiteName.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.updateReport();
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suites.Contains(suiteName))
            {
                ReportTemplate.suites.Add(suiteName);
                ReportTemplate.suiteReportData.Add(suiteName, new List<Int32>() { 0, 0 });
                ReportTemplate.currentSuite = suiteName;
                ReportTemplate.suiteCreated = true;
                ReportTemplate.testCreated = false;
            }
            ///////////////////////////

            // Outputs
            return (ctx) =>
            {
                try
                {
                    suiteList.Set(ctx, ReportTemplate.suites);
                }catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                    suiteList.Set(ctx, null);
                }
            };
        }

        #endregion
    }
}

