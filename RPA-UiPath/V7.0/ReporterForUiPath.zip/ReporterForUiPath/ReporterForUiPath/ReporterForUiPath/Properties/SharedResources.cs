﻿namespace UiPath.Shared.Localization
{
    class SharedResources : ReporterForUiPath.Properties.Resources
    {
    }
}