﻿using System.ComponentModel;

namespace ReporterForUiPath.Enums
{
    public enum StepStatus
    {
        [Description("Pass")]
        Pass,
        [Description("Fail")]
        Fail,
        [Description("Info")]
        Info,
        [Description("Warning")]
        Warning,
        [Description("Exception")]
        Exception,
        [Description("Skip")]
        Skip,
        [Description("Compare Actual-Expected")]
        Compare

    }
}
