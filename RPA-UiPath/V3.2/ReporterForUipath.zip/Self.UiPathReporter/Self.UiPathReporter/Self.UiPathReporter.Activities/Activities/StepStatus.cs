using System;
using System.Activities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Self.UiPathReporter.Activities.Activities.Template;
using Self.UiPathReporter.Activities.Properties;
using Self.UiPathReporter.Enums;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Self.UiPathReporter.Activities
{
    [LocalizedDisplayName(nameof(Resources.StepStatus_DisplayName))]
    [LocalizedDescription(nameof(Resources.StepStatus_Description))]
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class StepStatus : ContinuableAsyncCodeActivity

    {

        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_Status_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_Status_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public Self.UiPathReporter.Enums.StepStatus Status { get; set; } = Enums.StepStatus.Pass;

        //[LocalizedDisplayName(nameof(Resources.StepStatus_StepName_DisplayName))]
        //[LocalizedDescription(nameof(Resources.StepStatus_StepName_Description))]
        [LocalizedDisplayName("Name")]
        [LocalizedDescription("Text must be quoted.")]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Name { get; set; }

        //[LocalizedDisplayName(nameof(Resources.StepStatus_StepDescription_DisplayName))]
        //[LocalizedDescription(nameof(Resources.StepStatus_StepDescription_Description))]
        [LocalizedDisplayName("Description")]
        [LocalizedDescription("Text must be quoted.")]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Description { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_ExpectedResult_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_ExpectedResult_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> ExpectedResult { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_ActualResult_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_ActualResult_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> ActualResult { get; set; }

        //[LocalizedDisplayName(nameof(Resources.StepStatus_StepExceptionMessage_DisplayName))]
        //[LocalizedDescription(nameof(Resources.StepStatus_StepExceptionMessage_Description))]
        [LocalizedDisplayName("Code Block")]
        [LocalizedDescription("To display code messages, generaly used for exceptions.")]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public InArgument<string> ExceptionMessage { get; set; }

        [LocalizedDisplayName(nameof(Resources.StepStatus_TakeScreenshot_DisplayName))]
        [LocalizedDescription(nameof(Resources.StepStatus_TakeScreenshot_Description))]
        [LocalizedCategory(nameof(Resources.Options_Category))]
        public bool TakeScreenshot { get; set; } = true; 

        #endregion


        #region Constructors

        public StepStatus()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Name == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Name)));
            if (Description == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Description)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var name = Name.Get(context);
            var description = Description.Get(context);
            var expectedResult = ExpectedResult.Get(context);
            var actualResult = ActualResult.Get(context);
            var exceptionMessage = ExceptionMessage.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                ReportTemplate rp = new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suiteCreated)
            {
                ReportTemplate.suites.Add(ReportTemplate.currentSuite);
                ReportTemplate.suiteReportData.Add(ReportTemplate.currentSuite, new List<Int32>() { 0, 0 });
                ReportTemplate.suiteCreated = true;
            }
            if (!ReportTemplate.testCreated)
            {
                TestItem test = new TestItem("DefaultTest", "Default Test Created By UiPath Reporter", "", "Low");
                ReportTemplate.testItems.Add(ReportTemplate.currentTestId, test);
                ReportTemplate.testCreated = true;
                ReportTemplate.counts["parentCount"] = ReportTemplate.testItems.Count;
                ReportTemplate.counts["passParent"]++;
            }
            StepItem step = new StepItem(name, Status.ToString(), description, TakeScreenshot);
            step.stepException = (exceptionMessage==null) ? "" : exceptionMessage ;
            step.expectedResult = (expectedResult==null) ? "" : expectedResult ;
            step.actualResult = (actualResult==null) ? "" : actualResult ;
            ReportTemplate.endDate = Utility.getCurrentDate("/");
            ReportTemplate.endTime = Utility.getCurrentTime(":");
            ReportTemplate.testItems[ReportTemplate.currentTestId].endDate = ReportTemplate.endDate;
            ReportTemplate.testItems[ReportTemplate.currentTestId].endTime = ReportTemplate.endTime;
            ReportTemplate.testItems[ReportTemplate.currentTestId].stepItems.Add(step);
            ReportTemplate.updateReport();
            ///////////////////////////

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

