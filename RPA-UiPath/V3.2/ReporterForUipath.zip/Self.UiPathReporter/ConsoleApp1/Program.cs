﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
namespace ConsoleApp1
{
    class Program
    {
        public static List<string> dogs = new List<string>();
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Console.WriteLine(DateTime.Now.ToString("hh_mm_ss_ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.ffffff"));


            Console.ReadKey();
            //updateReport();
        }
    } 
}
