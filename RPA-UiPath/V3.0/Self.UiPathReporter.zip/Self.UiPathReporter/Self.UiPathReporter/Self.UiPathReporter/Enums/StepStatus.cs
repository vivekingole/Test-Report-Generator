﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Self.UiPathReporter.Enums
{
    public enum StepStatus
    {
        [Description("Pass")]
        Pass,
        [Description("Fail")]
        Fail,
        [Description("Info")]
        Info,
        [Description("Warning")]
        Warning,
        [Description("Exception")]
        Exception,
        [Description("Skip")]
        Skip

    }
}
