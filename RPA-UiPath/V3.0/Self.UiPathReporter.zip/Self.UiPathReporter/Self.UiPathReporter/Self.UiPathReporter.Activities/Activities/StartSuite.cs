using System;
using System.Activities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Self.UiPathReporter.Activities.Activities.Template;
using Self.UiPathReporter.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace Self.UiPathReporter.Activities
{
    [LocalizedDisplayName(nameof(Resources.StartSuite_DisplayName))]
    [LocalizedDescription(nameof(Resources.StartSuite_Description))]
    public class StartSuite : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.StartSuite_SuiteName_DisplayName))]
        [LocalizedDescription(nameof(Resources.StartSuite_SuiteName_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> SuiteName { get; set; }

        #endregion


        #region Constructors

        public StartSuite()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (SuiteName == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(SuiteName)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var suitename = SuiteName.Get(context);

            ///////////////////////////
            if (!ReportTemplate.reportCreated)
            {
                ReportTemplate rp = new ReportTemplate(ReportTemplate.reportName, ReportTemplate.reportLocation);
                ReportTemplate.updateReport();
                ReportTemplate.reportCreated = true;
            }
            if (!ReportTemplate.suites.Contains(suitename))
            {
                ReportTemplate.suites.Add(suitename);
                ReportTemplate.suiteReportData.Add(suitename, new List<Int32>() { 0, 0 });
                ReportTemplate.currentSuite = suitename;
                ReportTemplate.suiteCreated = true;
                ReportTemplate.testCreated = false;
            }
            ///////////////////////////

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

