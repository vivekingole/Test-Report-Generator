namespace Self.UiPathReporter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for CreateReportDesigner.xaml
    /// </summary>
    public partial class CreateReportDesigner
    {
        public CreateReportDesigner()
        {
            InitializeComponent();
        }
    }
}
