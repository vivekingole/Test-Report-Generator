namespace Self.UiPathReporter.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for StartTestDesigner.xaml
    /// </summary>
    public partial class StartTestDesigner
    {
        public StartTestDesigner()
        {
            InitializeComponent();
        }
    }
}
