﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Self.UiPathReporter.Activities.Design.Properties.Resources
    {
    }
}